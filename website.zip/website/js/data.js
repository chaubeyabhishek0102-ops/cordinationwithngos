/* ==========================================================================
   VolunteerLink - Centralized Data Store & Seed Database
   TY_B.Sc.CS Project: Volunteer Coordination for NGOs
   Authors: Kashish Sharad Durgoli & Abhishek Chaubey
   ========================================================================== */

const INITIAL_DB = {
  // Academic Synopsis Information
  synopsis: {
    projectTitle: "Volunteer Coordination for NGOs",
    authors: [
      { name: "Kashish Sharad Durgoli", role: "Developer & System Analyst" },
      { name: "Abhishek Chaubey", role: "Developer & UI/UX Architect" }
    ],
    class: "TY_B.Sc.CS",
    academicYear: "2026-2027",
    introduction: "Non-Governmental Organizations (NGOs) work for the welfare and development of society. Volunteers play a vital role in supporting NGOs in activities such as education, health awareness, environmental activities, food distribution, and community development. This project provides a centralized digital solution to manage volunteers, streamline activity assignments, track availability and attendance, and coordinate seamless communication.",
    problemStatement: [
      "Difficulty maintaining accurate, up-to-date volunteer records manually.",
      "Problems in matching volunteers to suitable activities based on specific skills and availability.",
      "Lack of structured communication and real-time coordination between NGOs and volunteers.",
      "Difficulty tracking volunteer availability, hours contributed, and event attendance.",
      "Time-consuming paperwork and unorganized volunteer management."
    ],
    objectives: [
      "Maintain a centralized digital record of volunteers and NGOs.",
      "Manage volunteer availability, skills, interests, and emergency preferences.",
      "Facilitate assignment of volunteers to suitable NGO activities and tasks.",
      "Enable real-time communication and notification coordination.",
      "Track volunteer participation, verified hours, and generate official certificates of appreciation."
    ],
    technologies: {
      frontend: "HTML5, Vanilla CSS3, Modern JavaScript (ES6+)",
      backend: "PHP (REST API architecture)",
      database: "MySQL (PhpMyAdmin)",
      tools: "Visual Studio Code, Chrome DevTools"
    }
  },

  // Active Users Database
  users: {
    volunteer: {
      id: "usr-vol-01",
      role: "volunteer",
      name: "Ravi Yadav",
      title: "Computer Science Student & Community Volunteer",
      email: "raviyadav@gmail.com",
      phone: "+91 98765 43210",
      location: "Mumbai, Maharashtra",
      joined: "Oct 12, 2026",
      avatar: "assets/images/ravi_avatar.jpg",
      quote: "Passionate about contributing to society and making a positive impact through volunteering.",
      about: "I am a Computer Science student passionate about using my skills for social good. I enjoy participating in community activities, helping NGOs and contributing to education, environment and disaster relief initiatives. I believe volunteering helps me learn, grow and make a positive impact in society.",
      skills: ["Communication", "Teaching", "Event Management", "Computer Skills", "First Aid"],
      interests: ["Education", "Environment", "Community Outreach", "Disaster Relief"],
      emergencyContact: {
        name: "Avdhesh Yadav (Father)",
        phone: "+91 98765 12345",
        relation: "Father"
      },
      availability: {
        days: ["Mon", "Wed", "Fri", "Sat"],
        preferredSlots: ["Morning (8AM - 12PM)", "Evening (4PM - 8PM)"]
      },
      privacy: {
        allowNgoView: true,
        showHoursPublic: true,
        showEmailPublic: false
      },
      notifications: {
        newOpportunities: true,
        applicationUpdates: true,
        ngoMessages: true,
        eventReminders: true,
        certificates: true,
        weeklySummary: true
      },
      stats: {
        hoursVolunteered: 48,
        completedActivities: 6,
        certificatesEarned: 4
      }
    },

    ngo_admin: {
      id: "usr-ngo-01",
      role: "ngo_admin",
      name: "Priya Nair",
      title: "Program Director",
      organization: "GreenRoots Foundation",
      email: "priya.nair@greenroots.org",
      phone: "+91 98200 55432",
      location: "Mumbai, Maharashtra",
      avatar: "assets/images/riya_director.jpg",
      regNumber: "NGO-MH-2018-0941",
      stats: {
        activeOpportunities: 4,
        totalVolunteersEngaged: 142,
        pendingApplications: 5,
        totalHoursApproved: 1240
      }
    },

    super_admin: {
      id: "usr-adm-01",
      role: "super_admin",
      name: "Admin Coordinator",
      title: "VolunteerLink Platform Administrator",
      email: "admin@volunteerlink.org",
      phone: "+91 99999 00000",
      location: "Mumbai, Maharashtra",
      avatar: "assets/images/riya_director.jpg",
      stats: {
        totalVolunteers: 12480,
        registeredNgos: 340,
        completedDrives: 1890,
        totalHoursCoordinated: 68450
      }
    }
  },

  // Volunteer Opportunities (Screenshot 4)
  opportunities: [
    {
      id: "opp-01",
      title: "Beach Cleanup Volunteer",
      ngo: "GreenRoots Foundation",
      ngoIcon: "🌱",
      status: "open",
      location: "Vasai, Maharashtra",
      startDate: "Nov 02, 2026",
      applyBy: "Oct 25, 2026",
      weeklyHours: 3,
      slotsTotal: 50,
      slotsLeft: 12,
      filledPercent: 76,
      categories: ["Environment", "Community Outreach", "Social Welfare"],
      skillsRequired: ["Communication", "Event Management"],
      description: "Join our eco-team to clean coastal stretches of Vasai beach, segregate plastics and promote environmental awareness in the local coastal community.",
      schedule: "Saturdays 7:00 AM - 10:00 AM",
      coordinator: "Priya Nair (GreenRoots Foundation)",
      bookmarked: false
    },
    {
      id: "opp-02",
      title: "Underprivileged Kids Teaching",
      ngo: "SevaSathi NGO",
      ngoIcon: "📖",
      status: "urgent",
      location: "Nallasopara, Maharashtra",
      startDate: "Oct 28, 2026",
      applyBy: "Oct 20, 2026",
      weeklyHours: 4,
      slotsTotal: 15,
      slotsLeft: 8,
      filledPercent: 53,
      categories: ["Education", "Youth Development", "Social Welfare"],
      skillsRequired: ["Teaching", "Mentoring", "Communication", "Computer Skills"],
      description: "Help teach basic English, Math and elementary computer literacy to underprivileged primary students at our community center.",
      schedule: "Mon & Wed 4:00 PM - 6:00 PM",
      coordinator: "Vikram Patil (SevaSathi NGO)",
      bookmarked: false
    },
    {
      id: "opp-03",
      title: "Hospital Support Volunteer",
      ngo: "HealthCare For All",
      ngoIcon: "🏥",
      status: "open",
      location: "Thane, Maharashtra",
      startDate: "Nov 05, 2026",
      applyBy: "Oct 28, 2026",
      weeklyHours: 6,
      slotsTotal: 25,
      slotsLeft: 10,
      filledPercent: 40,
      categories: ["Healthcare", "Social Welfare"],
      skillsRequired: ["Healthcare", "Communication", "First Aid"],
      description: "Assist outpatients, guide families through hospital documentation and provide emotional comfort at government civil hospitals.",
      schedule: "Tuesdays & Thursdays 9:00 AM - 12:00 PM",
      coordinator: "Dr. Aarti Mehta (HealthCare For All)",
      bookmarked: false
    },
    {
      id: "opp-04",
      title: "Women Empowerment Workshop",
      ngo: "Nari Shakti Trust",
      ngoIcon: "✨",
      status: "open",
      location: "Mumbai, Maharashtra",
      startDate: "Nov 10, 2026",
      applyBy: "Nov 01, 2026",
      weeklyHours: 4,
      slotsTotal: 20,
      slotsLeft: 15,
      filledPercent: 30,
      categories: ["Women Empowerment", "Economic Empowerment", "Education"],
      skillsRequired: ["Computer Skills", "Mentoring", "Teaching"],
      description: "Support hands-on workshops on digital banking, online business basics and vocational skills for women self-help groups.",
      schedule: "Fridays 2:00 PM - 6:00 PM",
      coordinator: "Sunita Sharma (Nari Shakti Trust)",
      bookmarked: false
    },
    {
      id: "opp-05",
      title: "Animal Shelter Volunteer",
      ngo: "Paws & Care",
      ngoIcon: "🐾",
      status: "open",
      location: "Thane, Maharashtra",
      startDate: "Oct 30, 2026",
      applyBy: "Oct 22, 2026",
      weeklyHours: 5,
      slotsTotal: 18,
      slotsLeft: 6,
      filledPercent: 67,
      categories: ["Animal Welfare", "Social Welfare"],
      skillsRequired: ["Caregiving", "First Aid"],
      description: "Assist with feeding rescued dogs and cats, administering medication, grooming and keeping shelter grounds sanitized.",
      schedule: "Weekends 8:00 AM - 1:00 PM",
      coordinator: "Karan Johar (Paws & Care)",
      bookmarked: false
    },
    {
      id: "opp-06",
      title: "Flood Relief Coordination Volunteer",
      ngo: "DisasterReady India",
      ngoIcon: "🌊",
      status: "urgent",
      location: "Pune, Maharashtra",
      startDate: "Nov 08, 2026",
      applyBy: "Oct 28, 2026",
      weeklyHours: 6,
      slotsTotal: 25,
      slotsLeft: 20,
      filledPercent: 20,
      categories: ["Disaster Relief", "Social Welfare"],
      skillsRequired: ["First Aid", "Communication", "Computer Skills"],
      description: "Assist in ground relief operations in flood-affected districts — distributing essential food packs, coordinating local logistics and supporting affected families.",
      schedule: "Rotational Day Shifts",
      coordinator: "Rajesh Shinde (DisasterReady India)",
      bookmarked: true
    },
    {
      id: "opp-07",
      title: "Youth Sports Coach",
      ngo: "SportForAll",
      ngoIcon: "⚽",
      status: "open",
      location: "Kolkata, West Bengal",
      startDate: "Nov 01, 2026",
      applyBy: "Oct 24, 2026",
      weeklyHours: 6,
      slotsTotal: 12,
      slotsLeft: 4,
      filledPercent: 66,
      categories: ["Youth Development", "Education"],
      skillsRequired: ["Sports Coaching", "Mentoring", "Communication"],
      description: "Coach football and cricket to underprivileged youth aged 8-16. Weekend fitness and team-building sessions at municipal grounds.",
      schedule: "Sat & Sun 7:00 AM - 10:00 AM",
      coordinator: "Sourav Ghosh (SportForAll)",
      bookmarked: false
    },
    {
      id: "opp-08",
      title: "Legal Aid Documentation Assistant",
      ngo: "JusticeFirst Foundation",
      ngoIcon: "⚖️",
      status: "open",
      location: "Hyderabad, Telangana",
      startDate: "Nov 15, 2026",
      applyBy: "Oct 30, 2026",
      weeklyHours: 8,
      slotsTotal: 10,
      slotsLeft: 3,
      filledPercent: 70,
      categories: ["Human Rights", "Social Welfare"],
      skillsRequired: ["Documentation", "Computer Skills", "Communication"],
      description: "Support free legal aid clinics by helping draft affidavit templates, organizing case dossiers and assisting low-income clients with paperwork.",
      schedule: "Mon to Wed 1:00 PM - 4:00 PM",
      coordinator: "Adv. Lakshmi Rao (JusticeFirst)",
      bookmarked: false
    },
    {
      id: "opp-09",
      title: "Tree Plantation & Urban Foresting",
      ngo: "GreenRoots Foundation",
      ngoIcon: "🌳",
      status: "open",
      location: "Mumbai, Maharashtra",
      startDate: "Nov 12, 2026",
      applyBy: "Nov 05, 2026",
      weeklyHours: 4,
      slotsTotal: 40,
      slotsLeft: 18,
      filledPercent: 55,
      categories: ["Environment", "Community Outreach"],
      skillsRequired: ["Event Management", "Communication"],
      description: "Plant native Indian tree saplings along suburban green belts and create Miyawaki mini-forests with school students.",
      schedule: "Sundays 8:00 AM - 12:00 PM",
      coordinator: "Priya Nair (GreenRoots Foundation)",
      bookmarked: false
    },
    {
      id: "opp-10",
      title: "Food Distribution Drive Volunteer",
      ngo: "Annam Relief Trust",
      ngoIcon: "🍲",
      status: "urgent",
      location: "Dharavi, Mumbai",
      startDate: "Oct 26, 2026",
      applyBy: "Oct 22, 2026",
      weeklyHours: 3,
      slotsTotal: 30,
      slotsLeft: 5,
      filledPercent: 83,
      categories: ["Social Welfare", "Disaster Relief"],
      skillsRequired: ["Event Management", "Communication"],
      description: "Pack and distribute nutritional cooked meals to migrant workers, daily wagers and destitute elderly citizens.",
      schedule: "Daily Evening Shift 6:00 PM - 9:00 PM",
      coordinator: "Mohammed Farooq (Annam Relief)",
      bookmarked: false
    },
    {
      id: "opp-11",
      title: "Digital Literacy for Senior Citizens",
      ngo: "AgeWell Foundation",
      ngoIcon: "👴",
      status: "open",
      location: "Bandra, Mumbai",
      startDate: "Nov 18, 2026",
      applyBy: "Nov 10, 2026",
      weeklyHours: 2,
      slotsTotal: 16,
      slotsLeft: 7,
      filledPercent: 56,
      categories: ["Education", "Social Welfare"],
      skillsRequired: ["Computer Skills", "Communication", "Teaching"],
      description: "Teach elderly residents how to use smartphones for video calling family, online bill payments, and cyber-safety precautions.",
      schedule: "Wednesdays 10:00 AM - 12:00 PM",
      coordinator: "Sharmila Bose (AgeWell)",
      bookmarked: false
    },
    {
      id: "opp-12",
      title: "Disaster Emergency Blood Donor Drive",
      ngo: "Red Cross Chapter",
      ngoIcon: "🩸",
      status: "urgent",
      location: "Dadar, Mumbai",
      startDate: "Oct 29, 2026",
      applyBy: "Oct 26, 2026",
      weeklyHours: 5,
      slotsTotal: 20,
      slotsLeft: 11,
      filledPercent: 45,
      categories: ["Healthcare", "Disaster Relief"],
      skillsRequired: ["First Aid", "Communication"],
      description: "Assist medical staff with donor registration, juice distribution, post-donation care and logistics at emergency blood camps.",
      schedule: "Thursday 9:00 AM - 2:00 PM",
      coordinator: "Dr. K. N. Sen (Red Cross)",
      bookmarked: false
    }
  ],

  // Volunteer's Applications (Screenshot 3)
  applications: [
    {
      id: "app-01",
      opportunityId: "opp-06",
      title: "Flood Relief Coordination Volunteer",
      ngo: "DisasterReady India",
      status: "accepted",
      appliedDate: "Sep 30, 2026",
      location: "Pune, Maharashtra",
      hoursWeek: "4-6 hrs/week",
      duration: "For 3 months",
      image: "assets/images/flood_relief.jpg",
      progressStep: 3, // 1: Applied, 2: Shortlisted, 3: Accepted, 4: Completed
      statusText: "Congratulations! Your application has been accepted. Check the next steps on the right.",
      timeline: [
        { title: "Application Submitted", time: "Sep 30, 2026, 10:24 AM", done: true },
        { title: "Shortlisted", time: "Oct 01, 2026, 02:15 PM", done: true },
        { title: "Accepted", time: "Oct 03, 2026, 11:40 AM", done: true },
        { title: "Onboarding Pending", time: "Scheduled for Oct 15, 2026", done: false }
      ]
    },
    {
      id: "app-02",
      opportunityId: "opp-07",
      title: "Youth Sports Coach",
      ngo: "SportForAll",
      status: "under_review",
      appliedDate: "Oct 05, 2026",
      location: "Kolkata, West Bengal",
      hoursWeek: "6 hrs/week",
      duration: "For 2 months",
      image: "assets/images/teaching_kids.jpg",
      progressStep: 2, // 1: Applied, 2: Under Review, 3: Shortlisted, 4: Completed
      statusText: "Your application is under review. The NGO will update you soon.",
      timeline: [
        { title: "Application Submitted", time: "Oct 05, 2026, 09:12 AM", done: true },
        { title: "Review in Progress", time: "Oct 06, 2026, 03:00 PM", done: true },
        { title: "Interview Scheduling", time: "Expected by Oct 18, 2026", done: false },
        { title: "Final Decision", time: "Pending", done: false }
      ]
    },
    {
      id: "app-03",
      opportunityId: "opp-08",
      title: "Legal Aid Documentation Assistant",
      ngo: "JusticeFirst Foundation",
      status: "shortlisted",
      appliedDate: "Oct 12, 2026",
      location: "Hyderabad, Telangana",
      hoursWeek: "8 hrs/week",
      duration: "For 3 months",
      image: "assets/images/hero_planting.jpg",
      progressStep: 2, // 1: Applied, 2: Shortlisted, 3: Interview, 4: Completed
      statusText: "You've been shortlisted! The NGO may contact you for the next steps.",
      timeline: [
        { title: "Application Submitted", time: "Oct 12, 2026, 11:30 AM", done: true },
        { title: "Shortlisted", time: "Oct 14, 2026, 04:20 PM", done: true },
        { title: "Virtual Interview", time: "Scheduled for Oct 19, 2026", done: false },
        { title: "Orientation", time: "Pending", done: false }
      ]
    }
  ],

  // Participation & Hours Log (Synopsis Objective 5: Attendance / Participation Tracking)
  hoursLog: [
    {
      id: "hr-01",
      date: "Oct 04, 2026",
      activity: "Flood Relief Supply Packaging & Triage",
      ngo: "DisasterReady India",
      hours: 16,
      status: "verified",
      supervisor: "Rajesh Shinde",
      notes: "Helped sort 400 medical dry ration kits and documented dispatch manifests."
    },
    {
      id: "hr-02",
      date: "Sep 22, 2026",
      activity: "Beach Cleanup Drive & Plastic Segregation",
      ngo: "GreenRoots Foundation",
      hours: 12,
      status: "verified",
      supervisor: "Priya Nair",
      notes: "Coordinated volunteer safety equipment and led clean-up of Zone 3."
    },
    {
      id: "hr-03",
      date: "Sep 15, 2026",
      activity: "Math & Coding Classes for Slum Children",
      ngo: "SevaSathi NGO",
      hours: 10,
      status: "verified",
      supervisor: "Vikram Patil",
      notes: "Delivered 5 sessions on basic arithmetic and visual logic games."
    },
    {
      id: "hr-04",
      date: "Sep 01, 2026",
      activity: "Urban Tree Plantation & Soil Prep",
      ngo: "GreenRoots Foundation",
      hours: 10,
      status: "verified",
      supervisor: "Priya Nair",
      notes: "Planted 50 saplings with youth volunteers at Aarey colony boundary."
    },
    {
      id: "hr-05",
      date: "Oct 14, 2026",
      activity: "Community Flood Relief Ground Survey",
      ngo: "DisasterReady India",
      hours: 6,
      status: "pending",
      supervisor: "Rajesh Shinde",
      notes: "Conducted preliminary needs assessment with affected families."
    }
  ],

  // Certificates Earned (Verified by NGOs)
  certificates: [
    {
      id: "cert-01",
      title: "Disaster Relief Champion 2026",
      ngo: "DisasterReady India",
      recipient: "Ravi Yadav",
      hours: 16,
      issuedDate: "October 05, 2026",
      certNumber: "VL-DRI-2026-8819",
      seal: "DisasterReady India Official Seal",
      signatory: "Rajesh Shinde, Operations Head"
    },
    {
      id: "cert-02",
      title: "Eco-Warrior Beach Conservation",
      ngo: "GreenRoots Foundation",
      recipient: "Ravi Yadav",
      hours: 12,
      issuedDate: "September 24, 2026",
      certNumber: "VL-GRF-2026-4402",
      seal: "GreenRoots Environment Seal",
      signatory: "Priya Nair, Program Director"
    },
    {
      id: "cert-03",
      title: "Excellence in Youth Teaching & Mentorship",
      ngo: "SevaSathi NGO",
      recipient: "Ravi Yadav",
      hours: 10,
      issuedDate: "September 18, 2026",
      certNumber: "VL-SS-2026-1930",
      seal: "SevaSathi Education Trust",
      signatory: "Vikram Patil, Lead Coordinator"
    },
    {
      id: "cert-04",
      title: "Urban Greenery & Afforestation Drive",
      ngo: "GreenRoots Foundation",
      recipient: "Ravi Yadav",
      hours: 10,
      issuedDate: "September 03, 2026",
      certNumber: "VL-GRF-2026-1184",
      seal: "GreenRoots Environment Seal",
      signatory: "Priya Nair, Program Director"
    }
  ],

  // Live Chat Threads (Communication System - Synopsis Item 4 & 7)
  chatThreads: [
    {
      id: "thread-01",
      ngoName: "GreenRoots Foundation",
      contactPerson: "Priya Nair",
      avatar: "assets/images/riya_director.jpg",
      online: true,
      lastMessage: "Looking forward to your assistance in the upcoming drive!",
      lastTime: "10:32 AM",
      unreadCount: 2,
      messages: [
        { sender: "ngo", text: "Hello Ravi! Thank you for expressing interest in our Beach Cleanup initiative.", time: "Yesterday, 3:15 PM" },
        { sender: "user", text: "Hello Priya ma'am! I am excited to support. What should I bring with me on Saturday?", time: "Yesterday, 3:45 PM" },
        { sender: "ngo", text: "We provide gloves and safety gear. Just bring a water bottle and wear comfortable shoes.", time: "Yesterday, 4:10 PM" },
        { sender: "ngo", text: "Looking forward to your assistance in the upcoming drive!", time: "10:32 AM" }
      ]
    },
    {
      id: "thread-02",
      ngoName: "DisasterReady India",
      contactPerson: "Rajesh Shinde",
      avatar: "assets/images/flood_relief.jpg",
      online: true,
      lastMessage: "Your emergency response ID card has been issued.",
      lastTime: "Yesterday",
      unreadCount: 1,
      messages: [
        { sender: "ngo", text: "Ravi, your flood relief application has been officially approved.", time: "Oct 03, 11:45 AM" },
        { sender: "user", text: "Thank you Rajesh sir! Ready whenever the deployment schedule starts.", time: "Oct 03, 12:00 PM" },
        { sender: "ngo", text: "Your emergency response ID card has been issued.", time: "Yesterday, 5:20 PM" }
      ]
    },
    {
      id: "thread-03",
      ngoName: "SevaSathi NGO",
      contactPerson: "Vikram Patil",
      avatar: "assets/images/teaching_kids.jpg",
      online: false,
      lastMessage: "The class timetable has been shared on the portal.",
      lastTime: "Oct 08",
      unreadCount: 0,
      messages: [
        { sender: "user", text: "Good evening sir, could you share the Grade 4 math syllabus?", time: "Oct 07, 6:00 PM" },
        { sender: "ngo", text: "The class timetable has been shared on the portal.", time: "Oct 08, 10:15 AM" }
      ]
    }
  ],

  // Registered Volunteers Roster (For Admin Overview & Task Assignment)
  volunteersList: [
    {
      id: "usr-vol-01",
      name: "Ravi Yadav",
      email: "raviyadav@gmail.com",
      phone: "+91 98765 43210",
      location: "Mumbai, Maharashtra",
      skills: ["Communication", "Teaching", "Event Management", "Computer Skills", "First Aid"],
      availability: "Mon, Wed, Fri, Sat",
      hoursVolunteered: 48,
      status: "Active on Drive",
      assignedDrive: "Flood Relief Coordination Volunteer",
      avatar: "assets/images/ravi_avatar.jpg"
    },
    {
      id: "usr-vol-02",
      name: "Sneha Kulkarni",
      email: "sneha.kulkarni@gmail.com",
      phone: "+91 98234 11223",
      location: "Pune, Maharashtra",
      skills: ["Teaching", "Mentoring", "Content Writing"],
      availability: "Tue, Thu, Sat",
      hoursVolunteered: 32,
      status: "Available",
      assignedDrive: "Underprivileged Kids Teaching",
      avatar: "assets/images/riya_director.jpg"
    },
    {
      id: "usr-vol-03",
      name: "Aman Verma",
      email: "aman.verma@outlook.com",
      phone: "+91 97112 88440",
      location: "Thane, Maharashtra",
      skills: ["First Aid", "Healthcare Support", "Logistics"],
      availability: "Weekends Only",
      hoursVolunteered: 24,
      status: "Active on Drive",
      assignedDrive: "Hospital Support Volunteer",
      avatar: "assets/images/ravi_avatar.jpg"
    },
    {
      id: "usr-vol-04",
      name: "Ananya Sen",
      email: "ananya.sen@gmail.com",
      phone: "+91 98301 77221",
      location: "Kolkata, West Bengal",
      skills: ["Sports Coaching", "Event Management", "First Aid"],
      availability: "Sat, Sun",
      hoursVolunteered: 18,
      status: "Available",
      assignedDrive: "Youth Sports Coach",
      avatar: "assets/images/riya_director.jpg"
    }
  ],

  // Registered Partner NGOs (For Super Admin & Multi-NGO Management)
  ngosList: [
    {
      id: "ngo-01",
      name: "GreenRoots Foundation",
      regNumber: "NGO-MH-2018-0941",
      adminName: "Priya Nair",
      email: "priya.nair@greenroots.org",
      phone: "+91 98200 55432",
      category: "Environment & Conservation",
      location: "Mumbai, Maharashtra",
      activeDrives: 3,
      volunteersCount: 65,
      status: "Verified & Active"
    },
    {
      id: "ngo-02",
      name: "DisasterReady India",
      regNumber: "NGO-MH-2020-1102",
      adminName: "Rajesh Shinde",
      email: "rajesh@disasterready.org",
      phone: "+91 98199 44332",
      category: "Disaster Relief & Emergency",
      location: "Pune, Maharashtra",
      activeDrives: 2,
      volunteersCount: 42,
      status: "Verified & Active"
    },
    {
      id: "ngo-03",
      name: "SevaSathi NGO",
      regNumber: "NGO-MH-2017-0451",
      adminName: "Vikram Patil",
      email: "contact@sevasathi.org",
      phone: "+91 98220 88991",
      category: "Education & Youth Welfare",
      location: "Nallasopara, Maharashtra",
      activeDrives: 2,
      volunteersCount: 38,
      status: "Verified & Active"
    },
    {
      id: "ngo-04",
      name: "HealthCare For All",
      regNumber: "NGO-MH-2019-0782",
      adminName: "Dr. Aarti Mehta",
      email: "info@healthcareforall.org",
      phone: "+91 98201 11334",
      category: "Healthcare & Public Aid",
      location: "Thane, Maharashtra",
      activeDrives: 2,
      volunteersCount: 29,
      status: "Verified & Active"
    }
  ],

  // Specific Tasks Assigned to Volunteers (Synopsis: Task Assignment & Monitoring)
  assignedTasks: [
    {
      id: "task-01",
      taskTitle: "Relief Packet Logistics & Ration Verification",
      volunteerName: "Ravi Yadav",
      volunteerId: "usr-vol-01",
      ngoName: "DisasterReady India",
      assignedBy: "Rajesh Shinde",
      assignedDate: "Oct 04, 2026",
      dueDate: "Nov 02, 2026",
      priority: "high",
      status: "in_progress",
      completionPercent: 65,
      instructions: "Inspect and verify 300 emergency medical and food packets before dispatch to Pune rural camps."
    },
    {
      id: "task-02",
      taskTitle: "Beach Safety Marshall & Volunteer Equipment Lead",
      volunteerName: "Ravi Yadav",
      volunteerId: "usr-vol-01",
      ngoName: "GreenRoots Foundation",
      assignedBy: "Priya Nair",
      assignedDate: "Sep 28, 2026",
      dueDate: "Nov 02, 2026",
      priority: "medium",
      status: "completed",
      completionPercent: 100,
      instructions: "Coordinate safety vests, gloves and trash collection bags distribution for 45 student volunteers."
    },
    {
      id: "task-03",
      taskTitle: "Primary Grade 4 & 5 Basic English Syllabus Prep",
      volunteerName: "Sneha Kulkarni",
      volunteerId: "usr-vol-02",
      ngoName: "SevaSathi NGO",
      assignedBy: "Vikram Patil",
      assignedDate: "Oct 06, 2026",
      dueDate: "Oct 28, 2026",
      priority: "medium",
      status: "in_progress",
      completionPercent: 40,
      instructions: "Prepare lesson worksheets and pictorial vocabulary charts for 20 slum center students."
    },
    {
      id: "task-04",
      taskTitle: "Hospital Outpatient Registration Assistance",
      volunteerName: "Aman Verma",
      volunteerId: "usr-vol-03",
      ngoName: "HealthCare For All",
      assignedBy: "Dr. Aarti Mehta",
      assignedDate: "Oct 10, 2026",
      dueDate: "Nov 05, 2026",
      priority: "high",
      status: "in_progress",
      completionPercent: 25,
      instructions: "Assist elderly patients with queue management and OPD form submission at Thane Civil Hospital."
    }
  ],

  // Live Work Stream / Audit Log (Synopsis: Real-time Oversight & Monitoring)
  workAuditLog: [
    {
      id: "log-1",
      event: "Hours Verified",
      detail: "Priya Nair approved 12 volunteer hours for Ravi Yadav (Beach Cleanup Drive).",
      timestamp: "15 minutes ago",
      icon: "✅",
      badgeColor: "green"
    },
    {
      id: "log-2",
      event: "Task In Progress",
      detail: "Ravi Yadav updated progress to 65% on 'Relief Packet Logistics'.",
      timestamp: "1 hour ago",
      icon: "⚡",
      badgeColor: "blue"
    },
    {
      id: "log-3",
      event: "New Task Assigned",
      detail: "Vikram Patil assigned 'English Syllabus Prep' to Sneha Kulkarni.",
      timestamp: "3 hours ago",
      icon: "📌",
      badgeColor: "purple"
    },
    {
      id: "log-4",
      event: "Application Shortlisted",
      detail: "JusticeFirst Foundation shortlisted Ravi Yadav for Legal Aid Assistant.",
      timestamp: "Yesterday",
      icon: "📋",
      badgeColor: "amber"
    },
    {
      id: "log-5",
      event: "Certificate Issued",
      detail: "Official Certificate 'Disaster Relief Champion 2026' generated for Ravi Yadav.",
      timestamp: "2 days ago",
      icon: "🎖️",
      badgeColor: "rose"
    }
  ],

  // System Notifications
  notifications: [
    { id: "nt-1", title: "Application Accepted!", desc: "DisasterReady India accepted your Flood Relief application.", time: "2 hours ago", unread: true },
    { id: "nt-2", title: "New Matching Opportunity", desc: "GreenRoots added Tree Plantation & Urban Foresting matching your skills.", time: "Yesterday", unread: true },
    { id: "nt-3", title: "Hours Approved", desc: "16 hours logged for Disaster Relief have been verified.", time: "2 days ago", unread: false },
    { id: "nt-4", title: "Certificate Ready", desc: "You received the 'Disaster Relief Champion 2026' certificate!", time: "3 days ago", unread: false }
  ]
};

// Storage helper functions
const DB = {
  load() {
    const raw = localStorage.getItem('volunteerlink_db');
    if (!raw) {
      this.save(INITIAL_DB);
      return INITIAL_DB;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      console.error("Error reading DB from localStorage, falling back to INITIAL_DB", e);
      return INITIAL_DB;
    }
  },
  save(data) {
    localStorage.setItem('volunteerlink_db', JSON.stringify(data));
  },
  reset() {
    this.save(INITIAL_DB);
    return INITIAL_DB;
  }
};
