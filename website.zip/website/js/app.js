/* ==========================================================================
   VolunteerLink - Main Application Controller & Reactive Engine
   TY_B.Sc.CS Project: Volunteer Coordination for NGOs
   Authors: Kashish Sharad Durgoli & Abhishek Chaubey
   ========================================================================== */

// Global Application State
const AppState = {
  db: DB.load(),
  currentRole: 'volunteer', // 'volunteer' | 'ngo_admin' | 'super_admin'
  currentView: 'landing',   // 'landing' | 'opportunities' | 'applications' | 'hours' | 'messages' | 'profile' | 'settings' | 'ngo_portal' | 'reports' | 'synopsis'
  activeChatThreadId: 'thread-01',
  selectedTimelineAppId: 'app-01',
  adminActiveTab: 'oversight', // 'oversight' | 'add_center' | 'volunteers' | 'applications'
  
  // Opportunities Filters State
  filters: {
    search: '',
    location: '',
    categories: [],
    maxHours: 40,
    openSlotsOnly: false,
    selectedSkills: [],
    sortBy: 'recent',
    viewMode: 'grid' // 'grid' | 'list'
  },

  // Applications Filter
  appStatusFilter: 'all' // 'all' | 'accepted' | 'under_review' | 'shortlisted' | 'rejected'
};

// Initialize Application on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initRouter();
  initAuthEvents();
  initGlobalHeader();
  renderCurrentView();
  setupGlobalModals();
});

/* ==========================================================================
   Router & View Switching
   ========================================================================== */

function navigateTo(viewName) {
  AppState.currentView = viewName;
  window.scrollTo({ top: 0, behavior: 'smooth' });
  renderCurrentView();
}

function initRouter() {
  // Delegate navigation clicks
  document.addEventListener('click', (e) => {
    const navLink = e.target.closest('[data-navigate]');
    if (navLink) {
      e.preventDefault();
      const targetView = navLink.getAttribute('data-navigate');
      navigateTo(targetView);
    }
  });
}

function renderCurrentView() {
  const appContainer = document.getElementById('app-view-container');
  const sidebar = document.getElementById('app-sidebar');
  const header = document.getElementById('app-header');

  // Highlight active link in sidebar
  document.querySelectorAll('.nav-item-link').forEach(link => {
    const view = link.getAttribute('data-navigate');
    if (view === AppState.currentView) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Landing page hides the standard dashboard shell
  if (AppState.currentView === 'landing') {
    if (sidebar) sidebar.style.display = 'none';
    if (header) header.style.display = 'none';
    appContainer.innerHTML = renderLandingPage();
    attachLandingEvents();
    return;
  }

  // Dashboard Shell is visible
  if (sidebar) sidebar.style.display = 'flex';
  if (header) header.style.display = 'flex';

  updateHeaderProfileBadge();
  updateSidebarBadges();

  switch (AppState.currentView) {
    case 'profile':
      appContainer.innerHTML = renderProfileView();
      attachProfileEvents();
      break;
    case 'opportunities':
      appContainer.innerHTML = renderOpportunitiesView();
      attachOpportunitiesEvents();
      break;
    case 'applications':
      appContainer.innerHTML = renderApplicationsView();
      attachApplicationsEvents();
      break;
    case 'hours':
      appContainer.innerHTML = renderHoursView();
      attachHoursEvents();
      break;
    case 'messages':
      appContainer.innerHTML = renderMessagesView();
      attachMessagesEvents();
      break;
    case 'ngo_portal':
      appContainer.innerHTML = renderNgoPortalView();
      attachNgoPortalEvents();
      break;
    case 'reports':
      appContainer.innerHTML = renderReportsView();
      attachReportsEvents();
      break;
    case 'synopsis':
      appContainer.innerHTML = renderSynopsisView();
      break;
    default:
      appContainer.innerHTML = renderOpportunitiesView();
      attachOpportunitiesEvents();
  }
}

/* ==========================================================================
   Header & Sidebar Global Helpers
   ========================================================================== */

function updateHeaderProfileBadge() {
  const user = AppState.db.users[AppState.currentRole];
  const nameEl = document.getElementById('header-user-name');
  const roleEl = document.getElementById('header-user-role');
  const avatarEl = document.getElementById('header-user-avatar');

  if (nameEl && user) nameEl.textContent = user.name;
  if (roleEl && user) {
    roleEl.textContent = AppState.currentRole === 'ngo_admin' ? 'NGO Admin' : (AppState.currentRole === 'super_admin' ? 'Super Admin' : 'Volunteer');
  }
  if (avatarEl && user) avatarEl.src = user.avatar;
}

function updateSidebarBadges() {
  // Applications Badge
  const appBadge = document.getElementById('sidebar-badge-apps');
  if (appBadge) {
    appBadge.textContent = AppState.db.applications.length;
  }

  // Messages Badge
  const msgBadge = document.getElementById('sidebar-badge-msgs');
  if (msgBadge) {
    let unread = 0;
    AppState.db.chatThreads.forEach(t => unread += (t.unreadCount || 0));
    msgBadge.textContent = unread > 0 ? unread : '';
    msgBadge.style.display = unread > 0 ? 'inline-block' : 'none';
  }
}

function initGlobalHeader() {
  // Global search enter key
  const searchInput = document.getElementById('global-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      AppState.filters.search = e.target.value;
      if (AppState.currentView === 'opportunities') {
        renderFilteredOpportunities();
      }
    });
    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        navigateTo('opportunities');
      }
    });
  }

  // Notification Bell
  const bellBtn = document.getElementById('btn-notification-bell');
  if (bellBtn) {
    bellBtn.addEventListener('click', toggleNotificationsModal);
  }

  // Location selector change
  const locSelector = document.getElementById('header-location-select');
  if (locSelector) {
    locSelector.addEventListener('click', () => {
      const cities = ["Mumbai, Maharashtra", "Pune, Maharashtra", "Thane, Maharashtra", "Kolkata, West Bengal", "Hyderabad, Telangana", "All Cities"];
      const current = locSelector.innerText.trim();
      let nextIdx = (cities.indexOf(current) + 1) % cities.length;
      if (nextIdx < 0) nextIdx = 0;
      locSelector.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg> ${cities[nextIdx]} <span style="font-size:10px;">▼</span>`;
      showToast(`Location filtered to: ${cities[nextIdx]}`);
      AppState.filters.location = cities[nextIdx] === "All Cities" ? "" : cities[nextIdx].split(',')[0];
      if (AppState.currentView === 'opportunities') renderFilteredOpportunities();
    });
  }
}

/* ==========================================================================
   VIEW 1: LANDING & AUTH LOGIC (Matches Screenshot 2)
   ========================================================================== */

function renderLandingPage() {
  return `
    <div class="landing-page-wrap">
      <div class="landing-ambient-orb orb-1"></div>
      <div class="landing-ambient-orb orb-2"></div>

      <!-- Top Navbar -->
      <header class="landing-navbar">
        <div class="landing-logo">
          <div class="sidebar-logo-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
          </div>
          <span class="sidebar-logo-text">Volunteer<span>Link</span></span>
        </div>

        <nav class="landing-nav-links">
          <a href="#" data-navigate="opportunities">Explore Opportunities</a>
          <a href="#" id="btn-view-synopsis-nav">Project Synopsis (TY B.Sc.CS)</a>
          <a href="#" onclick="showAboutModal()">About Project</a>
          <a href="#" onclick="showContactModal()">Contact</a>
        </nav>

        <div class="landing-nav-actions" style="display:flex; align-items:center; gap:10px;">
          <button class="btn-secondary" onclick="quickLoginRole('ngo_admin')" style="padding:8px 14px; font-size:13px; font-weight:700; border-color:#a7f3d0; background:#ecfdf5; color:#065f46;" title="Direct 1-Click Access to Admin Operations Hub">
            <span>⚡ Admin Portal</span>
          </button>
          <button class="btn-primary" onclick="quickLoginRole('volunteer')">
            <span>Sign In</span> &rarr;
          </button>
        </div>
      </header>

      <!-- Hero & Auth Section -->
      <main class="landing-hero-grid">
        <!-- Left Hero Content -->
        <div class="landing-hero-left">
          <div class="pill-tag">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66.95-2.3c.48.17.98.3 1.34.3C19 20 22 3 22 3c-1 2-8 2.25-13 3.25S2 11.5 2 13.5s1.75 3.75 1.75 3.75C7 8 17 8 17 8z"/></svg>
            Connecting people with purpose
          </div>

          <h1 class="landing-headline">
            Volunteer coordination, <span class="highlight">simplified.</span>
          </h1>

          <p class="landing-desc">
            VolunteerLink brings NGOs and volunteers together — post opportunities, manage applications, track attendance, and measure real-world impact seamlessly.
          </p>

          <div class="landing-stats-row">
            <div class="stat-item">
              <span class="stat-number">12,480</span>
              <span class="stat-label">Active Volunteers</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">340</span>
              <span class="stat-label">NGO Partners</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">28</span>
              <span class="stat-label">Districts & Cities</span>
            </div>
          </div>

          <!-- Testimonial Card -->
          <div class="landing-testimonial-card">
            <img src="assets/images/riya_director.jpg" alt="Riya Kapoor" class="testimonial-avatar" />
            <div>
              <p class="testimonial-text">"We went from spreadsheets to a fully managed volunteer pipeline in one week. Our coordinator saves 6 hours every week."</p>
              <div class="testimonial-author">Riya Kapoor</div>
              <div class="testimonial-role">Program Director, EarthFirst NGO</div>
            </div>
          </div>

          <!-- Hero Images Collage -->
          <div class="hero-visual-collage">
            <img src="assets/images/hero_planting.jpg" alt="Tree planting volunteers" class="hero-collage-img" />
            <img src="assets/images/teaching_kids.jpg" alt="Teaching kids" class="hero-collage-img" />
            <div class="hero-floating-badge">
              <span>🌱</span> Build Stronger Communities
            </div>
          </div>
        </div>

        <!-- Right Side: Interactive Sign-In Card (Matches Screenshot 2) -->
        <div class="auth-card">
          <div class="auth-header">
            <h2 class="auth-title">Welcome back</h2>
            <p class="auth-subtitle">Sign in to your VolunteerLink account</p>
          </div>

          <!-- Role Selector Pills -->
          <div class="role-tabs">
            <button class="role-tab-btn active" id="tab-auth-volunteer" onclick="switchAuthRole('volunteer')">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              Volunteer
            </button>
            <button class="role-tab-btn" id="tab-auth-ngo" onclick="switchAuthRole('ngo_admin')">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M8 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M16 14h.01"/></svg>
              NGO Admin
            </button>
            <button class="role-tab-btn" id="tab-auth-admin" onclick="switchAuthRole('super_admin')">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              Super Admin
            </button>
          </div>

          <form id="auth-login-form" onsubmit="handleAuthSubmit(event)">
            <div class="form-group">
              <label class="form-label">Email address</label>
              <div class="input-with-icon">
                <svg class="input-icon-left" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                <input type="email" id="auth-email-input" value="raviyadav@gmail.com" required placeholder="you@organization.org" />
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Password</label>
              <div class="input-with-icon">
                <svg class="input-icon-left" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <input type="password" id="auth-password-input" value="Volunteer@2026" required placeholder="Enter your password" />
                <svg class="input-icon-right" onclick="togglePasswordVisibility()" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </div>
            </div>

            <div class="form-options-row">
              <label class="remember-checkbox">
                <input type="checkbox" checked /> Remember me for 30 days
              </label>
              <a href="#" class="forgot-password-link" onclick="showToast('Password reset link sent to demo email!')">Forgot password?</a>
            </div>

            <button type="submit" class="btn-auth-submit" id="btn-submit-login">
              <span>Sign in as Volunteer</span> &rarr;
            </button>
          </form>

          <div class="auth-divider">or</div>

          <!-- Demo Accounts Autofill (Exact match to Screenshot 2) -->
          <div class="demo-accounts-box">
            <div class="demo-accounts-title">DEMO ACCOUNTS — CLICK TO AUTOFILL</div>
            
            <div class="demo-account-row">
              <span class="demo-account-tag volunteer">Volunteer</span>
              <span class="demo-account-email">amara.diallo@volunteerlink.org</span>
              <button class="btn-autofill-use" onclick="autofillLogin('volunteer', 'raviyadav@gmail.com', 'Volunteer@2026')">Use</button>
            </div>

            <div class="demo-account-row">
              <span class="demo-account-tag ngo">NGO Admin</span>
              <span class="demo-account-email">priya.nair@greenroots.org</span>
              <button class="btn-autofill-use" onclick="autofillLogin('ngo_admin', 'priya.nair@greenroots.org', 'NGOAdmin@2026')">Use</button>
            </div>

            <div class="demo-account-row">
              <span class="demo-account-tag admin">Super Admin</span>
              <span class="demo-account-email">admin@volunteerlink.org</span>
              <button class="btn-autofill-use" onclick="autofillLogin('super_admin', 'admin@volunteerlink.org', 'SuperAdmin@2026')">Use</button>
            </div>
          </div>

          <p style="font-size:11px; color:#94a3b8; text-align:center; margin-top:16px;">
            By continuing, you acknowledge our Terms of Service and Privacy Policy. TY_B.Sc.CS Project by Kashish & Abhishek.
          </p>
        </div>
      </main>
    </div>
  `;
}

function switchAuthRole(role) {
  AppState.currentRole = role;
  document.querySelectorAll('.role-tab-btn').forEach(btn => btn.classList.remove('active'));

  const submitBtn = document.getElementById('btn-submit-login');
  const emailInput = document.getElementById('auth-email-input');
  const passwordInput = document.getElementById('auth-password-input');

  if (role === 'volunteer') {
    document.getElementById('tab-auth-volunteer').classList.add('active');
    if (submitBtn) submitBtn.innerHTML = `<span>Sign in as Volunteer</span> &rarr;`;
    if (emailInput) emailInput.value = 'raviyadav@gmail.com';
    if (passwordInput) passwordInput.value = 'Volunteer@2026';
  } else if (role === 'ngo_admin') {
    document.getElementById('tab-auth-ngo').classList.add('active');
    if (submitBtn) submitBtn.innerHTML = `<span>Sign in as NGO Admin</span> &rarr;`;
    if (emailInput) emailInput.value = 'priya.nair@greenroots.org';
    if (passwordInput) passwordInput.value = 'NGOAdmin@2026';
  } else {
    document.getElementById('tab-auth-admin').classList.add('active');
    if (submitBtn) submitBtn.innerHTML = `<span>Sign in as Super Admin</span> &rarr;`;
    if (emailInput) emailInput.value = 'admin@volunteerlink.org';
    if (passwordInput) passwordInput.value = 'SuperAdmin@2026';
  }
}

function autofillLogin(role, email, pass) {
  switchAuthRole(role);
  document.getElementById('auth-email-input').value = email;
  document.getElementById('auth-password-input').value = pass;
  showToast(`Autofilled demo account for ${role}! Click 'Sign in' to proceed.`);
}

function handleAuthSubmit(e) {
  e.preventDefault();
  showToast(`Welcome back, ${AppState.db.users[AppState.currentRole].name}! Signed in successfully.`);
  
  // Direct to appropriate dashboard view
  if (AppState.currentRole === 'ngo_admin') {
    navigateTo('ngo_portal');
  } else if (AppState.currentRole === 'super_admin') {
    navigateTo('reports');
  } else {
    navigateTo('profile');
  }
}

function quickLoginRole(role) {
  AppState.currentRole = role;
  if (role === 'ngo_admin' || role === 'super_admin') {
    navigateTo('ngo_portal');
    showToast(`Logged in as ${role === 'ngo_admin' ? 'NGO Administrator (Priya Nair)' : 'Super Admin'}!`);
  } else {
    navigateTo('profile');
    showToast(`Logged in as Volunteer (Ravi Yadav)!`);
  }
}

function togglePasswordVisibility() {
  const input = document.getElementById('auth-password-input');
  if (input) {
    input.type = input.type === 'password' ? 'text' : 'password';
  }
}

function attachLandingEvents() {
  const synopsisNav = document.getElementById('btn-view-synopsis-nav');
  if (synopsisNav) {
    synopsisNav.addEventListener('click', (e) => {
      e.preventDefault();
      openSynopsisModal();
    });
  }
}

/* ==========================================================================
   VIEW 2: PROFILE PAGE (Matches Screenshot 1)
   ========================================================================== */

function calculateProfileCompletion(user) {
  let score = 0;
  if (user.name) score += 15;
  if (user.avatar) score += 15;
  if (user.quote) score += 10;
  if (user.about && user.about.length > 30) score += 15;
  if (user.skills && user.skills.length >= 3) score += 15;
  if (user.interests && user.interests.length >= 2) score += 10;
  if (user.availability && user.availability.days.length >= 2) score += 12;
  if (user.emergencyContact && user.emergencyContact.phone) score += 8;
  return Math.min(score, 100);
}

function renderProfileView() {
  const user = AppState.db.users.volunteer;
  const completion = calculateProfileCompletion(user);

  return `
    <div class="page-container">
      <!-- Breadcrumbs -->
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">Profile</span>
      </nav>

      <!-- Page Header -->
      <div class="page-header-row">
        <div>
          <h1 class="page-title">My Profile</h1>
          <p class="page-subtitle">Manage your profile, skills, availability and preferences</p>
        </div>
        <button class="btn-primary" onclick="openEditProfileModal()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
          Edit Profile
        </button>
      </div>

      <!-- Hero Profile Card (Matches Screenshot 1) -->
      <div class="profile-hero-card">
        <div class="profile-avatar-wrap">
          <img src="${user.avatar}" alt="${user.name}" class="profile-avatar-img" id="profile-display-avatar" />
          <button class="profile-avatar-camera-btn" onclick="openAvatarChangeModal()" title="Change Profile Picture">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
          </button>
        </div>

        <div class="profile-hero-details">
          <div class="profile-name-row">
            <h2 class="profile-name">${user.name}</h2>
            <span class="role-badge-pill">Volunteer</span>
          </div>

          <p class="profile-quote">"${user.quote}"</p>

          <div class="profile-contact-meta">
            <div class="profile-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
              <span>${user.location}</span>
            </div>
            <div class="profile-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              <span>${user.email}</span>
            </div>
            <div class="profile-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              <span>${user.phone}</span>
            </div>
            <div class="profile-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              <span>Joined ${user.joined}</span>
            </div>
          </div>
        </div>

        <!-- Completion Card -->
        <div class="profile-completion-box">
          <div class="completion-header">
            <span class="completion-title">Profile Completion</span>
            <span class="completion-percent">${completion}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width: ${completion}%;"></div>
          </div>
          <div class="completion-tip">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            <div>
              <strong style="color:#0f172a;">Almost complete!</strong> Add a short bio or skills to complete your profile.
            </div>
          </div>
        </div>
      </div>

      <!-- 3 Metrics KPI Row -->
      <div class="profile-metrics-row">
        <div class="metric-stat-card hours" onclick="navigateTo('hours')" title="View Logged Hours">
          <div class="metric-icon-wrap">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          </div>
          <div class="metric-value-block">
            <span class="metric-big-num">${user.stats.hoursVolunteered}</span>
            <span class="metric-title-sub">Hours Volunteered</span>
          </div>
        </div>

        <div class="metric-stat-card activities" onclick="navigateTo('applications')" title="View Applications">
          <div class="metric-icon-wrap">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div class="metric-value-block">
            <span class="metric-big-num">${user.stats.completedActivities}</span>
            <span class="metric-title-sub">Completed Activities</span>
          </div>
        </div>

        <div class="metric-stat-card certificates" onclick="navigateTo('hours')" title="View Certificates">
          <div class="metric-icon-wrap">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>
          </div>
          <div class="metric-value-block">
            <span class="metric-big-num">${user.stats.certificatesEarned}</span>
            <span class="metric-title-sub">Certificates Earned</span>
          </div>
          <div class="metric-card-arrow">&gt;</div>
        </div>
      </div>

      <!-- Bento Grid (Matches Screenshot 1 Left & Right Columns) -->
      <div class="profile-bento-grid">
        <!-- Left Column -->
        <div style="display:flex; flex-direction:column; gap:24px;">
          <!-- About Me Card -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                About Me
              </div>
              <button class="btn-card-edit" onclick="openEditAboutModal()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>
            <div class="bento-card-body" id="profile-about-text">
              ${user.about}
            </div>
          </div>

          <!-- Interests Card -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                Interests
              </div>
              <button class="btn-card-edit" onclick="openEditInterestsModal()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>
            <div class="tag-chips-wrap" id="profile-interests-chips">
              ${user.interests.map((int, i) => `<span class="pill-chip ${['green','blue','amber','purple'][i % 4]}">${int}</span>`).join('')}
            </div>
          </div>

          <!-- Emergency Contact Card -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                Emergency Contact
              </div>
              <button class="btn-card-edit" onclick="openEditEmergencyModal()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>
            <div class="info-key-val-grid">
              <div>
                <div class="key-label">Contact Name</div>
                <div class="val-text">${user.emergencyContact.name}</div>
              </div>
              <div>
                <div class="key-label">Phone Number</div>
                <div class="val-text">${user.emergencyContact.phone}</div>
              </div>
              <div>
                <div class="key-label">Relationship</div>
                <div class="val-text">${user.emergencyContact.relation}</div>
              </div>
            </div>
          </div>

          <!-- Notification Preferences Card -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                Notification Preferences
              </div>
              <button class="btn-card-edit" onclick="showToast('Notification preferences are editable live below!')">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>
            <div class="checkbox-grid">
              <label class="checkbox-item">
                <input type="checkbox" ${user.notifications.newOpportunities ? 'checked' : ''} onchange="toggleNotifyPref('newOpportunities', this.checked)" />
                New volunteer opportunities
              </label>
              <label class="checkbox-item">
                <input type="checkbox" ${user.notifications.eventReminders ? 'checked' : ''} onchange="toggleNotifyPref('eventReminders', this.checked)" />
                Event reminders
              </label>
              <label class="checkbox-item">
                <input type="checkbox" ${user.notifications.applicationUpdates ? 'checked' : ''} onchange="toggleNotifyPref('applicationUpdates', this.checked)" />
                Application updates
              </label>
              <label class="checkbox-item">
                <input type="checkbox" ${user.notifications.certificates ? 'checked' : ''} onchange="toggleNotifyPref('certificates', this.checked)" />
                Certificates and achievements
              </label>
              <label class="checkbox-item">
                <input type="checkbox" ${user.notifications.ngoMessages ? 'checked' : ''} onchange="toggleNotifyPref('ngoMessages', this.checked)" />
                Messages from NGOs
              </label>
              <label class="checkbox-item">
                <input type="checkbox" ${user.notifications.weeklySummary ? 'checked' : ''} onchange="toggleNotifyPref('weeklySummary', this.checked)" />
                Weekly summary
              </label>
            </div>
          </div>
        </div>

        <!-- Right Column -->
        <div style="display:flex; flex-direction:column; gap:24px;">
          <!-- Skills Card -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                Skills
              </div>
              <button class="btn-card-edit" onclick="openEditSkillsModal()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>
            <div class="tag-chips-wrap" id="profile-skills-chips">
              ${user.skills.map((sk, i) => `<span class="pill-chip ${['green','blue','amber','purple','rose'][i % 5]}">${sk}</span>`).join('')}
            </div>
          </div>

          <!-- Availability Card (Interactive Days & Preferred Time Slots) -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                Availability
              </div>
              <button class="btn-card-edit" onclick="showToast('Click any day to toggle availability!')">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>
            <p style="font-size:12.5px; color:#64748b; margin-bottom:8px;">I am usually available on the following days and times:</p>
            
            <div class="days-chips-row">
              ${["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(day => `
                <div class="day-chip ${user.availability.days.includes(day) ? 'active' : ''}" onclick="toggleAvailabilityDay('${day}')">
                  ${day}
                </div>
              `).join('')}
            </div>

            <div style="font-size:12px; font-weight:600; color:#475569; display:flex; align-items:center; gap:6px; margin-top:4px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              Preferred Time Slots
            </div>
            <div class="tag-chips-wrap" style="margin-top:8px;">
              ${user.availability.preferredSlots.map(slot => `<span class="pill-chip green">${slot}</span>`).join('')}
            </div>
          </div>

          <!-- Privacy Preferences Card -->
          <div class="bento-card">
            <div class="bento-card-header">
              <div class="bento-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                Privacy Preferences
              </div>
              <button class="btn-card-edit" onclick="showToast('Toggles update live!')">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg> Edit
              </button>
            </div>

            <div class="toggle-item-row">
              <div class="toggle-meta">
                <span class="toggle-label">Allow NGOs to view my profile and contact details</span>
                <span class="toggle-desc">Helps NGOs reach out for relevant opportunities</span>
              </div>
              <label class="switch-toggle">
                <input type="checkbox" ${user.privacy.allowNgoView ? 'checked' : ''} onchange="togglePrivacyPref('allowNgoView', this.checked)" />
                <span class="switch-slider"></span>
              </label>
            </div>

            <div class="toggle-item-row">
              <div class="toggle-meta">
                <span class="toggle-label">Show my volunteer hours on public profile</span>
                <span class="toggle-desc">Inspires others with your contribution</span>
              </div>
              <label class="switch-toggle">
                <input type="checkbox" ${user.privacy.showHoursPublic ? 'checked' : ''} onchange="togglePrivacyPref('showHoursPublic', this.checked)" />
                <span class="switch-slider"></span>
              </label>
            </div>

            <div class="toggle-item-row">
              <div class="toggle-meta">
                <span class="toggle-label">Show my email address publicly</span>
                <span class="toggle-desc">Only visible to NGO coordinators when off</span>
              </div>
              <label class="switch-toggle">
                <input type="checkbox" ${user.privacy.showEmailPublic ? 'checked' : ''} onchange="togglePrivacyPref('showEmailPublic', this.checked)" />
                <span class="switch-slider"></span>
              </label>
            </div>
          </div>
        </div>
      </div>

      <!-- Bottom Profile Actions -->
      <div class="profile-actions-bottom">
        <button class="btn-secondary" onclick="resetProfileChanges()">Cancel</button>
        <button class="btn-primary" onclick="saveAllProfileChanges()">Save Changes</button>
      </div>
    </div>
  `;
}

function toggleAvailabilityDay(day) {
  const user = AppState.db.users.volunteer;
  const idx = user.availability.days.indexOf(day);
  if (idx >= 0) {
    user.availability.days.splice(idx, 1);
  } else {
    user.availability.days.push(day);
  }
  DB.save(AppState.db);
  renderCurrentView();
  showToast(`Updated available days: ${user.availability.days.join(', ')}`);
}

function togglePrivacyPref(field, val) {
  AppState.db.users.volunteer.privacy[field] = val;
  DB.save(AppState.db);
  showToast('Privacy preferences updated.');
}

function toggleNotifyPref(field, val) {
  AppState.db.users.volunteer.notifications[field] = val;
  DB.save(AppState.db);
  showToast('Notification settings saved.');
}

function saveAllProfileChanges() {
  DB.save(AppState.db);
  showToast('All profile changes have been successfully saved!');
}

function resetProfileChanges() {
  AppState.db = DB.reset();
  renderCurrentView();
  showToast('Profile reset to original defaults.');
}

function attachProfileEvents() {}

/* ==========================================================================
   VIEW 3: OPPORTUNITIES EXPLORER (Matches Screenshot 4)
   ========================================================================== */

function renderOpportunitiesView() {
  return `
    <div class="page-container">
      <!-- Breadcrumbs -->
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">Volunteer Opportunities</span>
      </nav>

      <!-- Opportunities Header -->
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Volunteer Opportunities</h1>
          <p class="page-subtitle" id="opportunities-match-heading">12 opportunities matching your profile</p>
        </div>
        <div class="opportunities-controls">
          <div class="view-toggle-btns">
            <button class="btn-view-toggle active" id="btn-grid-view" onclick="setOppViewMode('grid')">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            </button>
            <button class="btn-view-toggle" id="btn-list-view" onclick="setOppViewMode('list')">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
            </button>
          </div>
          <select class="sort-select" id="opp-sort-select" onchange="handleOppSort(this.value)">
            <option value="recent">Sort: Most Recent</option>
            <option value="match">Sort: Highest Match</option>
            <option value="slots">Sort: Fewest Slots Left</option>
          </select>
        </div>
      </div>

      <!-- Main Layout: Filters Sidebar + Grid -->
      <div class="opportunities-layout">
        <!-- Filters Sidebar (Matches Screenshot 4 Left) -->
        <aside class="filters-sidebar">
          <div class="filters-header">
            <span class="filters-heading">Filters</span>
            <button class="btn-reset-filters" onclick="resetAllFilters()">Reset all</button>
          </div>

          <!-- Location Filter -->
          <div class="filter-group">
            <label class="filter-title">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
              Location
            </label>
            <div class="filter-location-input">
              <input type="text" id="filter-location-text" placeholder="City, area or state..." value="${AppState.filters.location}" oninput="handleLocationFilter(this.value)" />
              <svg class="btn-detect-gps" onclick="detectUserGps()" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/></svg>
            </div>
          </div>

          <!-- Cause Categories Checkboxes -->
          <div class="filter-group">
            <label class="filter-title">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              Cause Category
            </label>
            <div class="filter-checkbox-list">
              ${["Environment", "Education", "Healthcare", "Social Welfare", "Women Empowerment", "Animal Welfare", "Human Rights", "Disaster Relief", "Youth Development", "Economic Empowerment"].map(cat => `
                <label class="filter-checkbox-label">
                  <input type="checkbox" value="${cat}" ${AppState.filters.categories.includes(cat) ? 'checked' : ''} onchange="toggleCategoryFilter('${cat}', this.checked)" />
                  ${cat}
                </label>
              `).join('')}
            </div>
          </div>

          <!-- Max weekly hours slider -->
          <div class="filter-group">
            <label class="filter-title">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              Max weekly hours: <span id="label-slider-hours" style="color:var(--primary); font-weight:800;">${AppState.filters.maxHours}h</span>
            </label>
            <div class="hours-slider-row">
              <input type="range" min="2" max="40" step="1" value="${AppState.filters.maxHours}" oninput="handleHoursSlider(this.value)" />
              <div class="hours-labels-flex">
                <span>2h</span>
                <span>40h</span>
              </div>
            </div>
          </div>

          <!-- Open Slots Only Toggle -->
          <div class="filter-group">
            <label class="filter-checkbox-label" style="font-weight:600;">
              <input type="checkbox" id="chk-open-slots" ${AppState.filters.openSlotsOnly ? 'checked' : ''} onchange="toggleOpenSlotsOnly(this.checked)" />
              Has open slots only
            </label>
          </div>

          <!-- Skill Needed Tag Filter -->
          <div class="filter-group">
            <label class="filter-title">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              Skill Needed
            </label>
            <div class="tag-chips-wrap">
              ${["Teaching", "Communication", "Writing", "Healthcare", "Computer Skills", "Research", "Mentoring", "First Aid", "Sports Coaching", "Event Management", "Caregiving"].map(skill => `
                <span class="pill-chip clickable ${AppState.filters.selectedSkills.includes(skill) ? 'green' : 'inactive'}" onclick="toggleSkillFilter('${skill}')">
                  ${skill}
                </span>
              `).join('')}
            </div>
          </div>
        </aside>

        <!-- Opportunities Grid -->
        <main class="opportunities-main">
          <div class="opportunities-grid" id="opportunities-cards-container">
            <!-- Rendered by renderFilteredOpportunities() -->
          </div>
        </main>
      </div>
    </div>
  `;
}

function getFilteredOpportunities() {
  return AppState.db.opportunities.filter(opp => {
    // Search
    if (AppState.filters.search) {
      const q = AppState.filters.search.toLowerCase();
      const match = opp.title.toLowerCase().includes(q) ||
                    opp.ngo.toLowerCase().includes(q) ||
                    opp.categories.some(c => c.toLowerCase().includes(q)) ||
                    opp.skillsRequired.some(s => s.toLowerCase().includes(q));
      if (!match) return false;
    }
    // Location
    if (AppState.filters.location) {
      if (!opp.location.toLowerCase().includes(AppState.filters.location.toLowerCase())) return false;
    }
    // Categories
    if (AppState.filters.categories.length > 0) {
      const hasCat = opp.categories.some(c => AppState.filters.categories.includes(c));
      if (!hasCat) return false;
    }
    // Max Hours
    if (opp.weeklyHours > AppState.filters.maxHours) return false;
    // Open Slots Only
    if (AppState.filters.openSlotsOnly && opp.slotsLeft <= 0) return false;
    // Skills Needed
    if (AppState.filters.selectedSkills.length > 0) {
      const hasSkill = opp.skillsRequired.some(s => AppState.filters.selectedSkills.includes(s));
      if (!hasSkill) return false;
    }
    return true;
  }).sort((a, b) => {
    if (AppState.filters.sortBy === 'match') return b.filledPercent - a.filledPercent;
    if (AppState.filters.sortBy === 'slots') return a.slotsLeft - b.slotsLeft;
    return 0; // recent
  });
}

function renderFilteredOpportunities() {
  const container = document.getElementById('opportunities-cards-container');
  const countHeading = document.getElementById('opportunities-match-heading');
  if (!container) return;

  const list = getFilteredOpportunities();
  if (countHeading) {
    countHeading.innerHTML = `<strong>${list.length}</strong> opportunities matching your profile`;
  }

  if (list.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; background:white; padding:48px; border-radius:16px; text-align:center; border:1px solid #e2e8f0;">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="1.5" style="margin:0 auto 16px auto;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <h3 style="font-size:18px; font-weight:700; color:#0f172a; margin-bottom:6px;">No opportunities found</h3>
        <p style="color:#64748b; font-size:13.5px; margin-bottom:16px;">Try adjusting your cause category, weekly hours, or location filters.</p>
        <button class="btn-primary" onclick="resetAllFilters()">Reset All Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = list.map(opp => `
    <div class="opportunity-card" id="card-${opp.id}">
      <div class="opp-card-header">
        <div class="opp-ngo-badge">
          <div class="opp-ngo-icon">${opp.ngoIcon}</div>
          <span>${opp.ngo}</span>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
          <span class="opp-status-pill ${opp.status}">${opp.status === 'urgent' ? 'Urgent' : 'Open'}</span>
          <svg class="btn-bookmark ${opp.bookmarked ? 'bookmarked' : ''}" onclick="toggleBookmark('${opp.id}')" width="18" height="18" viewBox="0 0 24 24" fill="${opp.bookmarked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
        </div>
      </div>

      <h3 class="opp-card-title">${opp.title}</h3>
      <p class="opp-card-desc">${opp.description}</p>

      <div class="opp-meta-list">
        <div class="opp-meta-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
          <span>${opp.location}</span>
        </div>
        <div class="opp-meta-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          <span>${opp.startDate}</span>
        </div>
        <div class="opp-meta-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          <span>${opp.weeklyHours} hrs/week</span>
        </div>
        <div class="opp-meta-item" style="font-weight:600; color:#059669;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
          <span>${opp.slotsLeft} slots left</span>
        </div>
      </div>

      <!-- Progress Fill Bar -->
      <div class="opp-progress-wrap">
        <div class="opp-progress-bar">
          <div class="opp-progress-val" style="width: ${opp.filledPercent}%;"></div>
        </div>
        <div class="opp-progress-label">${opp.filledPercent}% filled</div>
      </div>

      <!-- Categories & Skills Tags -->
      <div class="tag-chips-wrap">
        ${opp.categories.slice(0, 2).map(c => `<span class="pill-chip green">${c}</span>`).join('')}
        ${opp.skillsRequired.slice(0, 2).map(s => `<span class="pill-chip blue">${s}</span>`).join('')}
      </div>

      <!-- Footer with Deadline & Actions -->
      <div class="opp-card-footer">
        <div class="opp-deadline-avatars">
          <span class="opp-deadline">Apply by ${opp.applyBy}</span>
          <div class="opp-avatars-stack">
            <img src="assets/images/ravi_avatar.jpg" alt="Volunteer" />
            <img src="assets/images/riya_director.jpg" alt="Volunteer" />
            <div class="avatar-chip" style="font-size:10px; display:flex; align-items:center; justify-content:center; font-weight:700; color:#475569;">+${opp.slotsTotal - opp.slotsLeft}</div>
          </div>
        </div>

        <div class="opp-card-actions">
          <button class="btn-card-details" onclick="openOpportunityDetailModal('${opp.id}')">View details</button>
          <button class="btn-card-apply" onclick="openApplyModal('${opp.id}')">Apply now &rarr;</button>
        </div>
      </div>
    </div>
  `).join('');
}

function attachOpportunitiesEvents() {
  renderFilteredOpportunities();
}

function handleLocationFilter(val) {
  AppState.filters.location = val;
  renderFilteredOpportunities();
}

function detectUserGps() {
  AppState.filters.location = "Mumbai";
  document.getElementById('filter-location-text').value = "Mumbai";
  renderFilteredOpportunities();
  showToast("Detected location: Mumbai, Maharashtra");
}

function toggleCategoryFilter(cat, checked) {
  if (checked) {
    AppState.filters.categories.push(cat);
  } else {
    AppState.filters.categories = AppState.filters.categories.filter(c => c !== cat);
  }
  renderFilteredOpportunities();
}

function handleHoursSlider(val) {
  AppState.filters.maxHours = parseInt(val);
  const lbl = document.getElementById('label-slider-hours');
  if (lbl) lbl.textContent = `${val}h`;
  renderFilteredOpportunities();
}

function toggleOpenSlotsOnly(checked) {
  AppState.filters.openSlotsOnly = checked;
  renderFilteredOpportunities();
}

function toggleSkillFilter(skill) {
  if (AppState.filters.selectedSkills.includes(skill)) {
    AppState.filters.selectedSkills = AppState.filters.selectedSkills.filter(s => s !== skill);
  } else {
    AppState.filters.selectedSkills.push(skill);
  }
  renderCurrentView();
}

function handleOppSort(val) {
  AppState.filters.sortBy = val;
  renderFilteredOpportunities();
}

function setOppViewMode(mode) {
  AppState.filters.viewMode = mode;
  document.getElementById('btn-grid-view').classList.toggle('active', mode === 'grid');
  document.getElementById('btn-list-view').classList.toggle('active', mode === 'list');
  const container = document.getElementById('opportunities-cards-container');
  if (container) {
    container.style.gridTemplateColumns = mode === 'grid' ? 'repeat(auto-fill, minmax(330px, 1fr))' : '1fr';
  }
}

function resetAllFilters() {
  AppState.filters.search = '';
  AppState.filters.location = '';
  AppState.filters.categories = [];
  AppState.filters.maxHours = 40;
  AppState.filters.openSlotsOnly = false;
  AppState.filters.selectedSkills = [];
  AppState.filters.sortBy = 'recent';
  renderCurrentView();
  showToast("All filters have been reset.");
}

function toggleBookmark(oppId) {
  const opp = AppState.db.opportunities.find(o => o.id === oppId);
  if (opp) {
    opp.bookmarked = !opp.bookmarked;
    DB.save(AppState.db);
    renderFilteredOpportunities();
    showToast(opp.bookmarked ? `Saved "${opp.title}" to bookmarks` : `Removed from bookmarks`);
  }
}

/* ==========================================================================
   VIEW 4: MY APPLICATIONS (Matches Screenshot 3)
   ========================================================================== */

function renderApplicationsView() {
  const apps = AppState.db.applications;
  const totalCount = apps.length;
  const acceptedCount = apps.filter(a => a.status === 'accepted').length;
  const reviewCount = apps.filter(a => a.status === 'under_review').length;
  const shortlistedCount = apps.filter(a => a.status === 'shortlisted').length;

  const filteredApps = apps.filter(a => {
    if (AppState.appStatusFilter === 'all') return true;
    return a.status === AppState.appStatusFilter;
  });

  const selectedApp = apps.find(a => a.id === AppState.selectedTimelineAppId) || apps[0] || {};

  return `
    <div class="page-container">
      <!-- Breadcrumbs -->
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">My Applications</span>
      </nav>

      <!-- Page Header -->
      <div class="page-header-row">
        <div>
          <h1 class="page-title">My Applications</h1>
          <p class="page-subtitle">Track every application from submission to completion.</p>
        </div>
      </div>

      <!-- 4 Stat Counters (Matches Screenshot 3 Top) -->
      <div class="applications-stats-grid">
        <div class="app-stat-card total">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${totalCount}</span>
            <span class="app-stat-title">Total Applications</span>
            <span class="app-stat-sub">All time</span>
          </div>
        </div>

        <div class="app-stat-card accepted">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${acceptedCount}</span>
            <span class="app-stat-title">Accepted</span>
            <span class="app-stat-sub">Start volunteering!</span>
          </div>
        </div>

        <div class="app-stat-card review">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${reviewCount}</span>
            <span class="app-stat-title">Under Review</span>
            <span class="app-stat-sub">In progress</span>
          </div>
        </div>

        <div class="app-stat-card shortlisted">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${shortlistedCount}</span>
            <span class="app-stat-title">Shortlisted</span>
            <span class="app-stat-sub">Next steps soon</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: Applications List + Right Rail -->
      <div class="applications-layout">
        <!-- Left: Filter Tabs & List -->
        <div>
          <div class="applications-tabs-row">
            <div class="filter-pills-list">
              <button class="pill-filter-btn ${AppState.appStatusFilter === 'all' ? 'active' : ''}" onclick="setAppStatusFilter('all')">All (${totalCount})</button>
              <button class="pill-filter-btn ${AppState.appStatusFilter === 'accepted' ? 'active' : ''}" onclick="setAppStatusFilter('accepted')">Accepted (${acceptedCount})</button>
              <button class="pill-filter-btn ${AppState.appStatusFilter === 'under_review' ? 'active' : ''}" onclick="setAppStatusFilter('under_review')">Under Review (${reviewCount})</button>
              <button class="pill-filter-btn ${AppState.appStatusFilter === 'shortlisted' ? 'active' : ''}" onclick="setAppStatusFilter('shortlisted')">Shortlisted (${shortlistedCount})</button>
              <button class="pill-filter-btn ${AppState.appStatusFilter === 'rejected' ? 'active' : ''}" onclick="setAppStatusFilter('rejected')">Rejected (0)</button>
            </div>
            <select class="sort-select">
              <option>Most Recent</option>
              <option>Alphabetical</option>
            </select>
          </div>

          <!-- Cards List -->
          <div class="application-cards-list">
            ${filteredApps.map(app => renderApplicationCardItem(app)).join('')}
          </div>
        </div>

        <!-- Right Rail: Next Steps & Selected Application Timeline -->
        <aside class="applications-right-rail">
          <!-- Next Steps Checklist Card -->
          <div class="next-steps-card">
            <div class="next-steps-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              Next steps
            </div>
            <p class="next-steps-sub">What you can do next.</p>

            <div class="steps-list">
              <div class="step-checklist-item">
                <span class="step-num-bubble">1</span>
                <div>
                  <div class="step-detail-title">Check application status</div>
                  <div class="step-detail-desc">Keep an eye on updates from NGOs.</div>
                </div>
              </div>
              <div class="step-checklist-item">
                <span class="step-num-bubble">2</span>
                <div>
                  <div class="step-detail-title">Complete your profile</div>
                  <div class="step-detail-desc">Add skills, availability and interests to get better matches.</div>
                </div>
              </div>
              <div class="step-checklist-item">
                <span class="step-num-bubble">3</span>
                <div>
                  <div class="step-detail-title">Respond to messages</div>
                  <div class="step-detail-desc">NGOs may contact you for interviews or more information.</div>
                </div>
              </div>
              <div class="step-checklist-item">
                <span class="step-num-bubble">4</span>
                <div>
                  <div class="step-detail-title">Be ready to start</div>
                  <div class="step-detail-desc">Once accepted, check the onboarding details and start making an impact!</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Application Timeline Card (Matches Screenshot 3 Right Bottom) -->
          <div class="timeline-card">
            <div class="timeline-header-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              Application Timeline
            </div>
            <div style="font-weight:700; font-size:13px; color:#0f172a; margin-top:6px;">${selectedApp.title || 'Volunteer Drive'}</div>
            <div class="timeline-target-opp">${selectedApp.ngo || 'NGO Partner'}</div>

            <div class="timeline-items">
              ${(selectedApp.timeline || []).map(event => `
                <div class="timeline-event">
                  <span class="timeline-bullet ${event.done ? 'done' : ''}"></span>
                  <div class="timeline-event-name">${event.title}</div>
                  <div class="timeline-event-time">${event.time}</div>
                </div>
              `).join('')}
            </div>

            <button class="btn-secondary" style="width:100%; justify-content:center;" onclick="showToast('You are viewing full timeline milestones!')">
              View Full Timeline
            </button>
          </div>
        </aside>
      </div>
    </div>
  `;
}

function renderApplicationCardItem(app) {
  // Stepper labels depending on status
  let step1 = { label: "Applied", active: true, done: true };
  let step2 = { label: "Shortlisted", active: false, done: false };
  let step3 = { label: "Accepted", active: false, done: false };
  let step4 = { label: "Completed", active: false, done: false };

  if (app.status === 'accepted') {
    step2.done = true;
    step3.active = true;
    step3.done = true;
  } else if (app.status === 'under_review') {
    step2.label = "Under Review";
    step2.active = true;
    step3.label = "Shortlisted";
  } else if (app.status === 'shortlisted') {
    step2.active = true;
    step2.done = true;
    step3.label = "Interview";
  }

  const statusClass = app.status === 'accepted' ? 'accepted' : (app.status === 'under_review' ? 'review' : 'shortlisted');

  return `
    <div class="application-card-item" onclick="selectApplicationForTimeline('${app.id}')">
      <img src="${app.image}" alt="${app.title}" class="app-thumb-img" />

      <div class="app-card-content">
        <div class="app-card-top">
          <div>
            <div class="app-ngo-status">
              <span class="app-ngo-name">${app.ngo}</span>
              <span class="pill-chip ${statusClass}">${app.status.replace('_', ' ').toUpperCase()}</span>
            </div>
            <h3 class="app-card-heading">${app.title}</h3>
          </div>
          <button style="color:#94a3b8; font-size:16px;" onclick="openApplicationActionMenu(event, '${app.id}')">&#8942;</button>
        </div>

        <!-- 4 Step Progress Stepper (Matches Screenshot 3) -->
        <div class="app-progress-stepper">
          <div class="stepper-line">
            <div class="stepper-line-fill" style="width: ${app.status === 'accepted' ? '75%' : (app.status === 'shortlisted' ? '50%' : '25%')};"></div>
          </div>
          <div class="stepper-step">
            <div class="step-dot completed"></div>
            <span class="step-title completed">${step1.label}</span>
          </div>
          <div class="stepper-step">
            <div class="step-dot ${step2.done ? 'completed' : (step2.active ? 'active-' + statusClass : '')}"></div>
            <span class="step-title ${step2.active || step2.done ? 'completed' : ''}">${step2.label}</span>
          </div>
          <div class="stepper-step">
            <div class="step-dot ${step3.done ? 'completed' : (step3.active ? 'active-' + statusClass : '')}"></div>
            <span class="step-title ${step3.active || step3.done ? 'completed' : ''}">${step3.label}</span>
          </div>
          <div class="stepper-step">
            <div class="step-dot ${step4.done ? 'completed' : ''}"></div>
            <span class="step-title">${step4.label}</span>
          </div>
        </div>

        <!-- Status Alert Banner -->
        <div class="app-status-banner ${statusClass}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
          <span>${app.statusText}</span>
        </div>

        <!-- Metadata Row & Details Button -->
        <div class="app-meta-bottom-row">
          <div class="app-meta-specs">
            <span>📍 ${app.location}</span>
            <span>📅 Applied on ${app.appliedDate}</span>
            <span>⏱️ ${app.hoursWeek}</span>
            <span>⏳ ${app.duration}</span>
          </div>
          <button class="btn-card-apply" style="padding:6px 14px; font-size:12.5px;" onclick="openApplicationDetailModal('${app.id}')">
            View Details &rarr;
          </button>
        </div>
      </div>
    </div>
  `;
}

function selectApplicationForTimeline(appId) {
  AppState.selectedTimelineAppId = appId;
  renderCurrentView();
}

function setAppStatusFilter(filter) {
  AppState.appStatusFilter = filter;
  renderCurrentView();
}

function attachApplicationsEvents() {}

/* ==========================================================================
   VIEW 5: MY HOURS & PARTICIPATION TRACKING (Synopsis Objective 5 & 6)
   ========================================================================== */

function renderHoursView() {
  const hoursList = AppState.db.hoursLog;
  const user = AppState.db.users.volunteer;
  let totalLogged = 0;
  let verified = 0;
  let pending = 0;

  hoursList.forEach(item => {
    totalLogged += item.hours;
    if (item.status === 'verified') verified += item.hours;
    else pending += item.hours;
  });

  return `
    <div class="page-container">
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">My Hours & Certificates</span>
      </nav>

      <div class="page-header-row">
        <div>
          <h1 class="page-title">Attendance & Participation Tracking</h1>
          <p class="page-subtitle">Track logged volunteer hours, verification records and earned certificates.</p>
        </div>
        <button class="btn-primary" onclick="openLogHoursModal()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          Log Volunteer Hours
        </button>
      </div>

      <!-- Stats Summary -->
      <div class="hours-top-stats">
        <div class="app-stat-card accepted">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${verified} hrs</span>
            <span class="app-stat-title">Verified Hours</span>
            <span class="app-stat-sub">Official credit</span>
          </div>
        </div>

        <div class="app-stat-card review">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 2v4"/><path d="M12 18v4"/><path d="M4.93 4.93l2.83 2.83"/><path d="M16.24 16.24l2.83 2.83"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${pending} hrs</span>
            <span class="app-stat-title">Pending Approval</span>
            <span class="app-stat-sub">Awaiting NGO verification</span>
          </div>
        </div>

        <div class="app-stat-card total">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${hoursList.length}</span>
            <span class="app-stat-title">Activities Logged</span>
            <span class="app-stat-sub">Across 4 NGOs</span>
          </div>
        </div>

        <div class="app-stat-card shortlisted">
          <div class="app-stat-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>
          </div>
          <div class="app-stat-details">
            <span class="app-stat-number">${AppState.db.certificates.length}</span>
            <span class="app-stat-title">Certificates Earned</span>
            <span class="app-stat-sub">Ready to download</span>
          </div>
        </div>
      </div>

      <!-- Assigned Duties & Live Task Progress -->
      <div class="hours-table-wrap" style="margin-bottom:24px;">
        <div class="table-header-row">
          <div>
            <h2 style="font-size:17px; font-weight:800; color:#0f172a;">Assigned Tasks & Live Work Progress</h2>
            <p style="font-size:12.5px; color:#64748b;">Direct responsibilities assigned to you by NGO coordinators.</p>
          </div>
          <span class="pill-chip green">Live Progress Tracking</span>
        </div>

        <div class="work-progress-grid" style="grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));">
          ${(AppState.db.assignedTasks || []).filter(t => t.volunteerName === 'Ravi Yadav').map(task => `
            <div class="work-progress-card">
              <div class="work-card-top">
                <div>
                  <span class="priority-pill ${task.priority}">${task.priority} Priority</span>
                  <h3 class="work-task-title" style="margin-top:6px; font-size:15px;">${task.taskTitle}</h3>
                  <div style="font-size:11.5px; color:#64748b;">Coordinator: <strong>${task.assignedBy} (${task.ngoName})</strong></div>
                </div>
              </div>

              <p style="font-size:12px; color:#475569; line-height:1.45;">${task.instructions}</p>

              <div class="work-progress-bar-wrap">
                <div class="work-bar-header">
                  <span>Work Completion</span>
                  <strong style="color:#0f172a;">${task.completionPercent}%</strong>
                </div>
                <div class="work-track">
                  <div class="work-fill" style="width:${task.completionPercent}%; ${task.completionPercent === 100 ? 'background:#10b981;' : ''}"></div>
                </div>
              </div>

              <div class="work-meta-footer">
                <span>Due: ${task.dueDate}</span>
                <span class="pill-chip ${task.status === 'completed' ? 'green' : 'amber'}">${task.status === 'completed' ? 'Completed' : 'In Progress'}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Logged Hours Table -->
      <div class="hours-table-wrap">
        <div class="table-header-row">
          <h2 style="font-size:17px; font-weight:700; color:#0f172a;">Volunteer Attendance Log</h2>
          <button class="btn-secondary" style="font-size:12.5px;" onclick="exportHoursCSV()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export Log (CSV)
          </button>
        </div>

        <table class="data-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Activity / Project</th>
              <th>Organization</th>
              <th>Hours</th>
              <th>Supervisor</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${hoursList.map(item => `
              <tr>
                <td><strong>${item.date}</strong></td>
                <td>${item.activity}</td>
                <td>${item.ngo}</td>
                <td><strong style="color:#0f172a;">${item.hours} hrs</strong></td>
                <td>${item.supervisor}</td>
                <td>
                  <span class="status-tag ${item.status}">${item.status === 'verified' ? 'Verified' : 'Pending'}</span>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- Certificates of Appreciation Section -->
      <div style="margin-top:36px;">
        <div class="page-header-row">
          <div>
            <h2 style="font-size:20px; font-weight:800; color:#0f172a;">Earned Certificates of Appreciation</h2>
            <p style="font-size:13.5px; color:#64748b;">Official certificates issued and verified by accredited NGOs.</p>
          </div>
        </div>

        <div class="certificates-grid">
          ${AppState.db.certificates.map(cert => `
            <div class="certificate-card">
              <div class="cert-card-header">
                <div class="cert-badge-icon">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>
                </div>
                <span class="pill-chip purple">Official</span>
              </div>
              <h3 class="cert-name">${cert.title}</h3>
              <div class="cert-meta">
                <div>Issued by: <strong>${cert.ngo}</strong></div>
                <div>Hours contributed: <strong>${cert.hours} hrs</strong></div>
                <div>Date: ${cert.issuedDate}</div>
                <div style="font-size:11px; color:#94a3b8; margin-top:4px;">ID: ${cert.certNumber}</div>
              </div>
              <button class="btn-outline-primary" style="margin-top:auto;" onclick="openCertificateModal('${cert.id}')">
                View & Print Certificate &rarr;
              </button>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

function attachHoursEvents() {}

function exportHoursCSV() {
  const rows = [
    ["Date", "Activity", "NGO", "Hours", "Supervisor", "Status"]
  ];
  AppState.db.hoursLog.forEach(h => {
    rows.push([h.date, `"${h.activity}"`, `"${h.ngo}"`, h.hours, `"${h.supervisor}"`, h.status]);
  });
  const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `Volunteer_Hours_Log_Ravi_Yadav.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast("Downloaded official volunteer attendance CSV report!");
}

/* ==========================================================================
   VIEW 6: MESSAGES & NGO COORDINATOR CHAT (Synopsis Item 4 & 7)
   ========================================================================== */

function renderMessagesView() {
  const threads = AppState.db.chatThreads;
  const activeThread = threads.find(t => t.id === AppState.activeChatThreadId) || threads[0];

  return `
    <div class="page-container">
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">Messages</span>
      </nav>

      <div class="page-header-row" style="margin-bottom:16px;">
        <div>
          <h1 class="page-title">Direct NGO Communication</h1>
          <p class="page-subtitle">Real-time messaging with assigned NGO coordinators and activity supervisors.</p>
        </div>
      </div>

      <!-- Chat Application Shell -->
      <div class="chat-app-container">
        <!-- Sidebar Threads -->
        <aside class="chat-sidebar">
          <div class="chat-sidebar-header">
            <input type="text" placeholder="Search conversations..." class="chat-search-input" />
          </div>

          <div class="chat-threads-list">
            ${threads.map(th => `
              <div class="chat-thread-item ${th.id === activeThread.id ? 'active' : ''}" onclick="selectChatThread('${th.id}')">
                <div class="thread-avatar-wrap">
                  <img src="${th.avatar}" alt="${th.ngoName}" class="thread-avatar" />
                  ${th.online ? '<span class="thread-online-dot"></span>' : ''}
                </div>
                <div class="thread-info">
                  <div class="thread-name-row">
                    <span class="thread-name">${th.contactPerson}</span>
                    <span class="thread-time">${th.lastTime}</span>
                  </div>
                  <div style="font-size:11px; color:#10b981; font-weight:600;">${th.ngoName}</div>
                  <div class="thread-last-msg">${th.lastMessage}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </aside>

        <!-- Main Chat Window -->
        <main class="chat-main-window">
          <header class="chat-window-header">
            <div class="chat-recipient-info">
              <img src="${activeThread.avatar}" alt="${activeThread.contactPerson}" style="width:40px; height:40px; border-radius:50%; object-fit:cover;" />
              <div>
                <div style="font-weight:700; font-size:15px; color:#0f172a;">${activeThread.contactPerson}</div>
                <div style="font-size:12px; color:#64748b;">Coordinator at <strong>${activeThread.ngoName}</strong> • ${activeThread.online ? '<span style="color:#10b981;">Online</span>' : 'Offline'}</div>
              </div>
            </div>

            <div style="display:flex; align-items:center; gap:10px;">
              <button class="btn-secondary" style="padding:6px 12px; font-size:12px;" onclick="showToast('Calling ${activeThread.contactPerson} via internet audio...')">
                📞 Call
              </button>
              <button class="btn-secondary" style="padding:6px 12px; font-size:12px;" onclick="showToast('Opening virtual briefing meeting...')">
                📹 Video
              </button>
            </div>
          </header>

          <!-- Chat Messages Body -->
          <div class="chat-messages-body" id="chat-messages-body">
            ${activeThread.messages.map(msg => `
              <div class="chat-bubble ${msg.sender === 'user' ? 'outgoing' : 'incoming'}">
                ${msg.text}
                <div class="chat-msg-time">${msg.time}</div>
              </div>
            `).join('')}
          </div>

          <!-- Quick Suggestion Chips -->
          <div style="padding:4px 20px; background:white; display:flex; gap:8px; overflow-x:auto;">
            <button class="pill-chip green clickable" onclick="sendQuickReply('I am available this Saturday for orientation.')">I am available this Saturday</button>
            <button class="pill-chip blue clickable" onclick="sendQuickReply('Please share the reporting location and kit requirements.')">Location & Kit requirements?</button>
            <button class="pill-chip amber clickable" onclick="sendQuickReply('Thank you so much! Looking forward to contributing.')">Thank you so much!</button>
          </div>

          <!-- Message Input Bar -->
          <form class="chat-input-area" onsubmit="handleSendMessage(event)">
            <button type="button" style="color:#94a3b8;" onclick="showToast('Attachment dialog simulation opened')">
              📎
            </button>
            <input type="text" id="chat-text-input" class="chat-text-input" placeholder="Type your message to ${activeThread.contactPerson}..." required autocomplete="off" />
            <button type="submit" class="btn-send-msg" title="Send message">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </form>
        </main>
      </div>
    </div>
  `;
}

function selectChatThread(threadId) {
  AppState.activeChatThreadId = threadId;
  const th = AppState.db.chatThreads.find(t => t.id === threadId);
  if (th) th.unreadCount = 0;
  DB.save(AppState.db);
  renderCurrentView();
  scrollChatToBottom();
}

function handleSendMessage(e) {
  e.preventDefault();
  const input = document.getElementById('chat-text-input');
  if (!input || !input.value.trim()) return;
  sendChatMessage(input.value.trim());
  input.value = '';
}

function sendQuickReply(text) {
  sendChatMessage(text);
}

function sendChatMessage(text) {
  const thread = AppState.db.chatThreads.find(t => t.id === AppState.activeChatThreadId);
  if (!thread) return;

  const newMsg = {
    sender: 'user',
    text: text,
    time: 'Just now'
  };

  thread.messages.push(newMsg);
  thread.lastMessage = text;
  thread.lastTime = 'Just now';
  DB.save(AppState.db);

  renderCurrentView();
  scrollChatToBottom();

  // Simulate coordinator reply after 1.2 seconds
  setTimeout(() => {
    const replies = [
      "Noted! We have updated the volunteer roster accordingly.",
      "Sounds great Ravi! Looking forward to seeing your leadership there.",
      "Got it. Our on-ground team will brief you as soon as you arrive at the venue.",
      "Thank you for the quick update! Your dedication is truly appreciated."
    ];
    const replyText = replies[Math.floor(Math.random() * replies.length)];
    thread.messages.push({
      sender: 'ngo',
      text: replyText,
      time: 'Just now'
    });
    thread.lastMessage = replyText;
    thread.lastTime = 'Just now';
    DB.save(AppState.db);
    renderCurrentView();
    scrollChatToBottom();
    showToast(`New message from ${thread.contactPerson}!`);
  }, 1200);
}

function scrollChatToBottom() {
  setTimeout(() => {
    const body = document.getElementById('chat-messages-body');
    if (body) body.scrollTop = body.scrollHeight;
  }, 50);
}

function attachMessagesEvents() {
  scrollChatToBottom();
}

/* ==========================================================================
   VIEW 7: NGO ADMIN PORTAL (Review Applications & Post Opportunity)
   ========================================================================== */

/* ==========================================================================
   VIEW 7: ADMIN PORTAL & LIVE WORK MONITOR ("Admin Add Kar Sake & Dekh Sake")
   ========================================================================== */

function renderNgoPortalView() {
  const ngo = AppState.db.users.ngo_admin;
  const activeTab = AppState.adminActiveTab || 'oversight';
  const pendingHours = (AppState.db.hoursLog || []).filter(h => h.status === 'pending');
  const activeTasks = AppState.db.assignedTasks || [];
  const volunteers = AppState.db.volunteersList || [];
  const applications = AppState.db.applications || [];

  return `
    <div class="page-container">
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">Admin Hub & Work Monitor</span>
      </nav>

      <!-- Page Header -->
      <div class="page-header-row">
        <div>
          <div style="display:flex; align-items:center; gap:10px; margin-bottom:4px;">
            <h1 class="page-title">Admin Work & Operations Hub</h1>
            <span class="pill-chip green">Live System Control</span>
          </div>
          <p class="page-subtitle">Monitor volunteer work in real-time, assign tasks, review applications, and add new resources.</p>
        </div>
        <div style="display:flex; gap:10px; align-items:center;">
          <button class="btn-secondary" onclick="quickLoginRole('volunteer')">
            Volunteer View
          </button>
          <button class="btn-primary" onclick="switchAdminTab('add_center')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            + Admin Add Center
          </button>
        </div>
      </div>

      <!-- Admin Tab Navigation Bar -->
      <div class="admin-tab-nav">
        <button class="admin-tab-btn ${activeTab === 'oversight' ? 'active' : ''}" onclick="switchAdminTab('oversight')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          📊 Work Progress & Live Oversight
        </button>
        <button class="admin-tab-btn ${activeTab === 'add_center' ? 'active' : ''}" onclick="switchAdminTab('add_center')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
          ➕ Admin Add Center (Add New Resource)
        </button>
        <button class="admin-tab-btn ${activeTab === 'volunteers' ? 'active' : ''}" onclick="switchAdminTab('volunteers')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          👥 Volunteer Directory (${volunteers.length})
        </button>
        <button class="admin-tab-btn ${activeTab === 'applications' ? 'active' : ''}" onclick="switchAdminTab('applications')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          📋 Applications (${applications.length}) & Hours (${pendingHours.length} pending)
        </button>
      </div>

      <!-- TAB 1: WORK PROGRESS & LIVE OVERSIGHT ("Dekh Sake Kaisa Work Ho Raha Hai") -->
      ${activeTab === 'oversight' ? `
        <!-- High Level Summary Metrics -->
        <div class="hours-top-stats" style="margin-bottom:24px;">
          <div class="app-stat-card accepted">
            <div class="app-stat-icon">⚡</div>
            <div class="app-stat-details">
              <span class="app-stat-number">${activeTasks.length} Tasks</span>
              <span class="app-stat-title">Active Deployments</span>
              <span class="app-stat-sub">Across community drives</span>
            </div>
          </div>
          <div class="app-stat-card total">
            <div class="app-stat-icon">👥</div>
            <div class="app-stat-details">
              <span class="app-stat-number">${volunteers.length} Active</span>
              <span class="app-stat-title">Volunteers on Roster</span>
              <span class="app-stat-sub">Ready for assignment</span>
            </div>
          </div>
          <div class="app-stat-card review">
            <div class="app-stat-icon">⏳</div>
            <div class="app-stat-details">
              <span class="app-stat-number">${pendingHours.reduce((sum, h) => sum + h.hours, 0)} hrs</span>
              <span class="app-stat-title">Pending Verification</span>
              <span class="app-stat-sub">${pendingHours.length} logs to review</span>
            </div>
          </div>
          <div class="app-stat-card shortlisted">
            <div class="app-stat-icon">🏅</div>
            <div class="app-stat-details">
              <span class="app-stat-number">${AppState.db.certificates.length} Issued</span>
              <span class="app-stat-title">Certificates Awarded</span>
              <span class="app-stat-sub">Official recognition</span>
            </div>
          </div>
        </div>

        <!-- Two Column Oversight Layout: Active Tasks Progress + Live Audit Stream -->
        <div style="display:grid; grid-template-columns:1.5fr 1fr; gap:24px; align-items:start;">
          <!-- Left: Active Tasks Progress Cards -->
          <div style="display:flex; flex-direction:column; gap:18px;">
            <div class="bento-card-header" style="margin-bottom:-4px;">
              <h2 style="font-size:18px; font-weight:800; color:#0f172a;">Active Volunteer Tasks Progress</h2>
              <button class="btn-outline-primary" style="padding:4px 10px; font-size:12px;" onclick="openAssignTaskModal()">
                + Assign New Task
              </button>
            </div>

            <div class="work-progress-grid" style="grid-template-columns:1fr;">
              ${activeTasks.map(task => `
                <div class="work-progress-card">
                  <div class="work-card-top">
                    <div>
                      <span class="priority-pill ${task.priority}">${task.priority} Priority</span>
                      <h3 class="work-task-title" style="margin-top:6px;">${task.taskTitle}</h3>
                      <div style="font-size:12px; color:#64748b; margin-top:2px;">Organized by: <strong>${task.ngoName}</strong></div>
                    </div>
                    <button class="btn-card-edit" style="font-size:12px;" onclick="openUpdateTaskProgressModal('${task.id}')">
                      Update %
                    </button>
                  </div>

                  <div class="work-assigned-to">
                    <img src="assets/images/ravi_avatar.jpg" alt="Avatar" style="width:28px; height:28px; border-radius:50%; object-fit:cover;" />
                    <div>
                      <strong style="color:#0f172a;">${task.volunteerName}</strong>
                      <span style="font-size:11px; color:#64748b;"> • Assigned by ${task.assignedBy}</span>
                    </div>
                  </div>

                  <p style="font-size:12.5px; color:#475569; line-height:1.45;">${task.instructions}</p>

                  <div class="work-progress-bar-wrap">
                    <div class="work-bar-header">
                      <span>Task Completion</span>
                      <span style="color:#0f172a; font-weight:700;">${task.completionPercent}%</span>
                    </div>
                    <div class="work-track">
                      <div class="work-fill" style="width:${task.completionPercent}%; ${task.completionPercent === 100 ? 'background:#10b981;' : ''}"></div>
                    </div>
                  </div>

                  <div class="work-meta-footer">
                    <span>📅 Assigned: ${task.assignedDate}</span>
                    <span style="font-weight:600; color:#e11d48;">⏳ Due: ${task.dueDate}</span>
                    <span class="pill-chip ${task.status === 'completed' ? 'green' : 'amber'}">${task.status === 'completed' ? 'Completed' : 'In Progress'}</span>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Right: Live Activity Audit Feed -->
          <div class="bento-card" style="padding:22px;">
            <div class="bento-card-header" style="margin-bottom:14px;">
              <div class="bento-card-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                Live Work Audit Stream
              </div>
              <span class="pill-chip green">Real-Time</span>
            </div>
            <p style="font-size:12px; color:#64748b; margin-bottom:16px;">Live log of hours logged, tasks updated, and status changes across the platform:</p>

            <div class="audit-stream-container">
              ${(AppState.db.workAuditLog || []).map(log => `
                <div class="audit-stream-item">
                  <div class="audit-icon-wrap">${log.icon}</div>
                  <div class="audit-content">
                    <div class="audit-event-title">${log.event}</div>
                    <div class="audit-event-detail">${log.detail}</div>
                    <div class="audit-time">${log.timestamp}</div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      ` : ''}

      <!-- TAB 2: ADMIN ADD CENTER ("Admin Add Kar Sake") -->
      ${activeTab === 'add_center' ? `
        <div style="margin-bottom:24px;">
          <h2 style="font-size:20px; font-weight:800; color:#0f172a; margin-bottom:6px;">Admin Resource Creation Center</h2>
          <p style="font-size:13.5px; color:#64748b;">Add new opportunities, assign volunteers directly, register new NGO partners, or issue official certificates.</p>
        </div>

        <div class="admin-action-cards-grid">
          <!-- Action 1: Post Opportunity -->
          <div class="admin-action-card opp">
            <div class="action-card-icon">📢</div>
            <h3 class="action-card-title">Post New Opportunity</h3>
            <p class="action-card-desc">Publish a new volunteer drive with required slots, skills, location, dates, and weekly hours quota.</p>
            <button class="btn-primary" style="margin-top:auto;" onclick="openPostOpportunityModal()">
              + Post Opportunity &rarr;
            </button>
          </div>

          <!-- Action 2: Assign Task to Volunteer -->
          <div class="admin-action-card task">
            <div class="action-card-icon">📌</div>
            <h3 class="action-card-title">Assign Task to Volunteer</h3>
            <p class="action-card-desc">Directly delegate a specific task to any registered volunteer with target deadline, priority and instructions.</p>
            <button class="btn-primary" style="margin-top:auto; background:#8b5cf6;" onclick="openAssignTaskModal()">
              + Assign Volunteer &rarr;
            </button>
          </div>

          <!-- Action 3: Register New NGO Partner -->
          <div class="admin-action-card ngo">
            <div class="action-card-icon">🏢</div>
            <h3 class="action-card-title">Register New NGO Partner</h3>
            <p class="action-card-desc">Onboard a verified NGO to the platform with registration license, director details, and cause focus area.</p>
            <button class="btn-primary" style="margin-top:auto; background:#0284c7;" onclick="openAddNewNgoModal()">
              + Register NGO &rarr;
            </button>
          </div>

          <!-- Action 4: Issue Certificate -->
          <div class="admin-action-card cert">
            <div class="action-card-icon">🎖️</div>
            <h3 class="action-card-title">Issue Official Certificate</h3>
            <p class="action-card-desc">Generate and award a verified Certificate of Appreciation to a volunteer for outstanding community service.</p>
            <button class="btn-primary" style="margin-top:auto; background:#d97706;" onclick="openIssueCertificateModal()">
              + Issue Certificate &rarr;
            </button>
          </div>
        </div>

        <!-- Registered NGOs Overview -->
        <div class="hours-table-wrap">
          <div class="table-header-row">
            <div>
              <h2 style="font-size:17px; font-weight:700; color:#0f172a;">Registered NGO Partners (${(AppState.db.ngosList || []).length})</h2>
              <p style="font-size:12.5px; color:#64748b;">Accredited NGOs operating on the VolunteerLink platform.</p>
            </div>
            <button class="btn-primary" style="font-size:12.5px;" onclick="openAddNewNgoModal()">
              + Register New NGO
            </button>
          </div>

          <table class="data-table">
            <thead>
              <tr>
                <th>NGO Name & Reg Number</th>
                <th>Coordinator</th>
                <th>Focus Category</th>
                <th>Location</th>
                <th>Active Drives</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${(AppState.db.ngosList || []).map(n => `
                <tr>
                  <td>
                    <strong>${n.name}</strong>
                    <div style="font-size:11px; color:#64748b;">Reg: ${n.regNumber}</div>
                  </td>
                  <td>
                    <div>${n.adminName}</div>
                    <div style="font-size:11px; color:#64748b;">${n.email}</div>
                  </td>
                  <td><span class="pill-chip blue">${n.category}</span></td>
                  <td>${n.location}</td>
                  <td><strong>${n.activeDrives} Drives</strong></td>
                  <td><span class="status-tag verified">${n.status}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : ''}

      <!-- TAB 3: VOLUNTEER DIRECTORY & TASK ASSIGNMENT -->
      ${activeTab === 'volunteers' ? `
        <div class="hours-table-wrap">
          <div class="table-header-row">
            <div>
              <h2 style="font-size:18px; font-weight:800; color:#0f172a;">Registered Volunteers Roster</h2>
              <p style="font-size:13px; color:#64748b;">View volunteer skills, weekly availability, completed hours and assign duties directly.</p>
            </div>
            <button class="btn-primary" onclick="openAssignTaskModal()">
              + Assign Task to Volunteer
            </button>
          </div>

          <table class="data-table">
            <thead>
              <tr>
                <th>Volunteer Name</th>
                <th>Contact & Location</th>
                <th>Skills & Availability</th>
                <th>Hours Contributed</th>
                <th>Current Status</th>
                <th>Admin Actions</th>
              </tr>
            </thead>
            <tbody>
              ${volunteers.map(vol => `
                <tr>
                  <td>
                    <div style="display:flex; align-items:center; gap:10px;">
                      <img src="${vol.avatar}" alt="${vol.name}" style="width:38px; height:38px; border-radius:50%; object-fit:cover;" />
                      <div>
                        <strong style="color:#0f172a; font-size:14px;">${vol.name}</strong>
                        <div style="font-size:11.5px; color:#64748b;">${vol.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div>${vol.phone}</div>
                    <div style="font-size:11.5px; color:#64748b;">📍 ${vol.location}</div>
                  </td>
                  <td>
                    <div class="tag-chips-wrap" style="margin-bottom:4px;">
                      ${vol.skills.slice(0, 2).map(s => `<span class="pill-chip green" style="font-size:11px;">${s}</span>`).join('')}
                    </div>
                    <div style="font-size:11px; color:#475569;">🗓️ Available: <strong>${vol.availability}</strong></div>
                  </td>
                  <td>
                    <strong style="color:#0f172a; font-size:14px;">${vol.hoursVolunteered} hrs</strong>
                  </td>
                  <td>
                    <span class="pill-chip ${vol.status.includes('Active') ? 'green' : 'amber'}">${vol.status}</span>
                  </td>
                  <td>
                    <button class="btn-primary" style="padding:6px 12px; font-size:12px;" onclick="openAssignTaskModal('${vol.id}')">
                      Assign Task &rarr;
                    </button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : ''}

      <!-- TAB 4: APPLICATIONS & HOURS VERIFICATION QUEUE -->
      ${activeTab === 'applications' ? `
        <!-- Hours Verification Queue -->
        <div class="hours-table-wrap" style="margin-bottom:28px;">
          <div class="table-header-row">
            <div>
              <h2 style="font-size:18px; font-weight:800; color:#0f172a;">Volunteer Hours Verification Queue</h2>
              <p style="font-size:13px; color:#64748b;">Review and approve attendance logged by volunteers to award official community service credit.</p>
            </div>
            <span class="pill-chip amber">${pendingHours.length} Pending Approval</span>
          </div>

          <table class="data-table">
            <thead>
              <tr>
                <th>Date Worked</th>
                <th>Activity / Project</th>
                <th>NGO Partner</th>
                <th>Hours</th>
                <th>Supervisor & Notes</th>
                <th>Verification Actions</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.db.hoursLog.map(record => `
                <tr>
                  <td><strong>${record.date}</strong></td>
                  <td><strong>${record.activity}</strong></td>
                  <td>${record.ngo}</td>
                  <td><strong style="color:#0f172a; font-size:14px;">${record.hours} hrs</strong></td>
                  <td>
                    <div>Supervisor: <strong>${record.supervisor}</strong></div>
                    <div style="font-size:11.5px; color:#64748b;">${record.notes || 'No extra notes provided.'}</div>
                  </td>
                  <td>
                    ${record.status === 'pending' ? `
                      <div class="admin-action-btn-group">
                        <button class="btn-status-action accept" onclick="approveVolunteerHours('${record.id}')">Approve Hours</button>
                        <button class="btn-status-action reject" onclick="rejectVolunteerHours('${record.id}')">Reject</button>
                      </div>
                    ` : `
                      <span class="status-tag verified">Verified</span>
                    `}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <!-- Volunteer Applications Review Table -->
        <div class="hours-table-wrap">
          <div class="table-header-row">
            <div>
              <h2 style="font-size:18px; font-weight:800; color:#0f172a;">Review Volunteer Applications (${applications.length})</h2>
              <p style="font-size:13px; color:#64748b;">Accept, Shortlist or Reject applicants to assign tasks in real-time.</p>
            </div>
          </div>

          <table class="data-table">
            <thead>
              <tr>
                <th>Applicant</th>
                <th>Target Opportunity</th>
                <th>Applied Date</th>
                <th>Current Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${applications.map(app => `
                <tr>
                  <td>
                    <div style="display:flex; align-items:center; gap:10px;">
                      <img src="${app.image || 'assets/images/ravi_avatar.jpg'}" alt="Avatar" style="width:36px; height:36px; border-radius:50%; object-fit:cover;" />
                      <div>
                        <strong style="color:#0f172a;">Ravi Yadav</strong>
                        <div style="font-size:11.5px; color:#64748b;">Location: Mumbai, Maharashtra</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <strong>${app.title}</strong>
                    <div style="font-size:11.5px; color:#64748b;">${app.location}</div>
                  </td>
                  <td>${app.appliedDate}</td>
                  <td>
                    <span class="status-tag ${app.status === 'accepted' ? 'verified' : (app.status === 'under_review' ? 'pending' : 'verified')}">
                      ${app.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </td>
                  <td>
                    <div class="admin-action-btn-group">
                      <button class="btn-status-action accept" onclick="setAppStatusAdmin('${app.id}', 'accepted')">Accept</button>
                      <button class="btn-status-action shortlist" onclick="setAppStatusAdmin('${app.id}', 'shortlisted')">Shortlist</button>
                      <button class="btn-status-action reject" onclick="setAppStatusAdmin('${app.id}', 'rejected')">Reject</button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : ''}
    </div>
  `;
}

function switchAdminTab(tabName) {
  AppState.adminActiveTab = tabName;
  renderCurrentView();
}

function setAppStatusAdmin(appId, newStatus) {
  const app = AppState.db.applications.find(a => a.id === appId);
  if (app) {
    app.status = newStatus;
    if (newStatus === 'accepted') {
      app.statusText = "Congratulations! Your application has been accepted. Check the next steps on the right.";
      app.progressStep = 3;
    } else if (newStatus === 'shortlisted') {
      app.statusText = "You've been shortlisted! The NGO coordinator will contact you shortly.";
      app.progressStep = 2;
    } else {
      app.statusText = "Application concluded.";
      app.progressStep = 1;
    }

    // Add event to audit log
    AppState.db.workAuditLog.unshift({
      id: `log-${Date.now()}`,
      event: `Application ${newStatus.toUpperCase()}`,
      detail: `Application for '${app.title}' marked as ${newStatus} by Admin.`,
      timestamp: 'Just now',
      icon: newStatus === 'accepted' ? '✅' : '📋',
      badgeColor: newStatus === 'accepted' ? 'green' : 'amber'
    });

    DB.save(AppState.db);
    renderCurrentView();
    showToast(`Application updated to: ${newStatus.toUpperCase()}`);
  }
}

function approveVolunteerHours(recordId) {
  const record = AppState.db.hoursLog.find(h => h.id === recordId);
  if (record) {
    record.status = 'verified';
    AppState.db.users.volunteer.stats.hoursVolunteered += record.hours;
    AppState.db.users.volunteer.stats.completedActivities += 1;
    AppState.db.users.ngo_admin.stats.totalHoursApproved += record.hours;

    AppState.db.workAuditLog.unshift({
      id: `log-${Date.now()}`,
      event: 'Hours Approved',
      detail: `Admin approved ${record.hours} volunteer hours for '${record.activity}'.`,
      timestamp: 'Just now',
      icon: '✅',
      badgeColor: 'green'
    });

    DB.save(AppState.db);
    renderCurrentView();
    showToast(`Approved ${record.hours} hours! Volunteer portfolio credited.`);
  }
}

function rejectVolunteerHours(recordId) {
  const record = AppState.db.hoursLog.find(h => h.id === recordId);
  if (record) {
    record.status = 'rejected';
    DB.save(AppState.db);
    renderCurrentView();
    showToast(`Hours log record rejected.`);
  }
}

function attachNgoPortalEvents() {}


/* ==========================================================================
   VIEW 8: REPORTS & ACADEMIC SYNOPSIS (Synopsis Requirements)
   ========================================================================== */

function renderReportsView() {
  return `
    <div class="page-container">
      <nav class="breadcrumb-nav">
        <a href="#" data-navigate="opportunities">Home</a>
        <span class="breadcrumb-separator">&gt;</span>
        <span style="color:#0f172a; font-weight:600;">System Reports & Analytics</span>
      </nav>

      <div class="page-header-row">
        <div>
          <h1 class="page-title">Activity Reports & Platform Analytics</h1>
          <p class="page-subtitle">Comprehensive coordination metrics for NGOs, volunteers, and academic project submission.</p>
        </div>
        <div style="display:flex; gap:10px;">
          <button class="btn-secondary" onclick="exportHoursCSV()">
            Export Volunteer Data (CSV)
          </button>
          <button class="btn-primary" onclick="openSynopsisModal()">
            View Project Synopsis (PDF Spec)
          </button>
        </div>
      </div>

      <!-- Platform Overview Metrics -->
      <div class="applications-stats-grid">
        <div class="app-stat-card accepted">
          <div class="app-stat-icon">👥</div>
          <div class="app-stat-details">
            <span class="app-stat-number">12,480</span>
            <span class="app-stat-title">Registered Volunteers</span>
            <span class="app-stat-sub">Across Maharashtra</span>
          </div>
        </div>
        <div class="app-stat-card total">
          <div class="app-stat-icon">🏢</div>
          <div class="app-stat-details">
            <span class="app-stat-number">340</span>
            <span class="app-stat-title">Verified NGOs</span>
            <span class="app-stat-sub">Actively posting drives</span>
          </div>
        </div>
        <div class="app-stat-card review">
          <div class="app-stat-icon">⏱️</div>
          <div class="app-stat-details">
            <span class="app-stat-number">68,450 hrs</span>
            <span class="app-stat-title">Hours Contributed</span>
            <span class="app-stat-sub">Social welfare impact</span>
          </div>
        </div>
        <div class="app-stat-card shortlisted">
          <div class="app-stat-icon">🏅</div>
          <div class="app-stat-details">
            <span class="app-stat-number">4,120</span>
            <span class="app-stat-title">Certificates Issued</span>
            <span class="app-stat-sub">Digitally verified</span>
          </div>
        </div>
      </div>

      <!-- Project Synopsis Card Highlight -->
      <div class="bento-card" style="margin-top:20px;">
        <div class="bento-card-header">
          <div class="bento-card-title">
            <span>🎓</span> Academic Project Information (TY B.Sc.CS)
          </div>
          <span class="pill-chip green">Complete Submission</span>
        </div>
        <p style="font-size:14px; line-height:1.6; color:#475569;">
          <strong>Project Title:</strong> Volunteer Coordination for NGOs<br/>
          <strong>Students:</strong> Kashish Sharad Durgoli & Abhishek Chaubey<br/>
          <strong>Class:</strong> TY_B.Sc.CS | <strong>Database:</strong> MySQL (PhpMyAdmin schema included) | <strong>Backend:</strong> PHP & LocalStorage Architecture.
        </p>
      </div>
    </div>
  `;
}

function attachReportsEvents() {}

/* ==========================================================================
   VIEW 9: SYNOPSIS DOCUMENT MODAL & VIEW
   ========================================================================== */

function renderSynopsisView() {
  const s = AppState.db.synopsis;
  return `
    <div class="page-container">
      <div class="synopsis-container">
        <div class="synopsis-header">
          <span class="pill-tag" style="margin-bottom:12px;">TY_B.Sc.CS Academic Project</span>
          <h1 class="synopsis-title">${s.projectTitle}</h1>
          <div class="synopsis-authors">
            ${s.authors.map(a => `<span>${a.name} (${a.role})</span>`).join(' • ')}
          </div>
          <div style="font-size:13px; color:#64748b; margin-top:6px;">Class: ${s.class} | Academic Year: ${s.academicYear}</div>
        </div>

        <div class="synopsis-section">
          <h3>1. Introduction</h3>
          <p>${s.introduction}</p>
        </div>

        <div class="synopsis-section">
          <h3>2. Problem Statement</h3>
          <ul class="synopsis-list">
            ${s.problemStatement.map(p => `<li>${p}</li>`).join('')}
          </ul>
        </div>

        <div class="synopsis-section">
          <h3>3. Objectives</h3>
          <ul class="synopsis-list">
            ${s.objectives.map(o => `<li>${o}</li>`).join('')}
          </ul>
        </div>

        <div class="synopsis-section">
          <h3>4. Technologies Used</h3>
          <p>
            <strong>Frontend:</strong> ${s.technologies.frontend}<br/>
            <strong>Backend:</strong> ${s.technologies.backend}<br/>
            <strong>Database:</strong> ${s.technologies.database}<br/>
            <strong>Development Tool:</strong> ${s.technologies.tools}
          </p>
        </div>

        <div style="text-align:center; margin-top:30px;">
          <button class="btn-primary" onclick="window.print()">Print Project Synopsis</button>
        </div>
      </div>
    </div>
  `;
}

/* ==========================================================================
   MODAL CONTROLLERS & INTERACTION MANAGERS
   ========================================================================== */

function setupGlobalModals() {
  // Close modal when clicking backdrop
  document.querySelectorAll('.modal-backdrop').forEach(bd => {
    bd.addEventListener('click', (e) => {
      if (e.target === bd) {
        bd.classList.remove('open');
      }
    });
  });
}

function closeModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.remove('open');
}

function openModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.add('open');
}

// Edit Profile Modal
function openEditProfileModal() {
  const user = AppState.db.users.volunteer;
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  if (!content) return;

  title.textContent = "Edit Personal Profile";
  content.innerHTML = `
    <form onsubmit="handleSaveProfileForm(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Full Name</label>
        <input type="text" id="edit-name" value="${user.name}" required class="chat-text-input" />
      </div>
      <div class="form-group">
        <label class="form-label">Location</label>
        <input type="text" id="edit-location" value="${user.location}" required class="chat-text-input" />
      </div>
      <div class="form-group">
        <label class="form-label">Phone Number</label>
        <input type="text" id="edit-phone" value="${user.phone}" required class="chat-text-input" />
      </div>
      <div class="form-group">
        <label class="form-label">Inspirational Bio Quote</label>
        <input type="text" id="edit-quote" value="${user.quote}" required class="chat-text-input" />
      </div>
      <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Save Profile</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleSaveProfileForm(e) {
  e.preventDefault();
  const user = AppState.db.users.volunteer;
  user.name = document.getElementById('edit-name').value;
  user.location = document.getElementById('edit-location').value;
  user.phone = document.getElementById('edit-phone').value;
  user.quote = document.getElementById('edit-quote').value;
  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast("Profile details updated successfully!");
}

// Edit About Me Modal
function openEditAboutModal() {
  const user = AppState.db.users.volunteer;
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Edit About Me";
  content.innerHTML = `
    <form onsubmit="handleSaveAboutForm(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Tell NGOs about your passion and community involvement</label>
        <textarea id="edit-about-area" rows="6" style="width:100%; border:1px solid #cbd5e1; border-radius:10px; padding:12px; font-size:13.5px; outline:none;" required>${user.about}</textarea>
      </div>
      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Save Changes</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleSaveAboutForm(e) {
  e.preventDefault();
  AppState.db.users.volunteer.about = document.getElementById('edit-about-area').value;
  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast("About Me description updated!");
}

// Edit Skills Modal
function openEditSkillsModal() {
  const user = AppState.db.users.volunteer;
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Manage Skills";
  content.innerHTML = `
    <div>
      <p style="font-size:13px; color:#64748b; margin-bottom:12px;">Add or remove skills to match with relevant NGO opportunities.</p>
      <div class="tag-chips-wrap" id="modal-skills-list" style="margin-bottom:16px;">
        ${user.skills.map(sk => `
          <span class="pill-chip green">
            ${sk}
            <span style="cursor:pointer; margin-left:4px;" onclick="removeSkillTag('${sk}')">&times;</span>
          </span>
        `).join('')}
      </div>

      <div style="display:flex; gap:8px; margin-bottom:20px;">
        <input type="text" id="new-skill-input" placeholder="Type a skill (e.g. Photography, Data Analysis)..." class="chat-text-input" />
        <button type="button" class="btn-primary" onclick="addNewSkillTag()">Add</button>
      </div>

      <div style="display:flex; justify-content:flex-end;">
        <button type="button" class="btn-primary" onclick="closeModal('generic-modal')">Done</button>
      </div>
    </div>
  `;
  openModal('generic-modal');
}

function removeSkillTag(skill) {
  AppState.db.users.volunteer.skills = AppState.db.users.volunteer.skills.filter(s => s !== skill);
  DB.save(AppState.db);
  openEditSkillsModal();
  renderCurrentView();
}

function addNewSkillTag() {
  const input = document.getElementById('new-skill-input');
  if (input && input.value.trim()) {
    const val = input.value.trim();
    if (!AppState.db.users.volunteer.skills.includes(val)) {
      AppState.db.users.volunteer.skills.push(val);
      DB.save(AppState.db);
      openEditSkillsModal();
      renderCurrentView();
    }
    input.value = '';
  }
}

// Edit Interests Modal
function openEditInterestsModal() {
  const user = AppState.db.users.volunteer;
  const allCauses = ["Education", "Environment", "Community Outreach", "Disaster Relief", "Healthcare", "Animal Welfare", "Women Empowerment"];
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Select Your Causes & Interests";

  content.innerHTML = `
    <div>
      <p style="font-size:13px; color:#64748b; margin-bottom:14px;">Select the causes you are most passionate about contributing to:</p>
      <div class="tag-chips-wrap" style="gap:10px; margin-bottom:24px;">
        ${allCauses.map(cause => `
          <span class="pill-chip clickable ${user.interests.includes(cause) ? 'green' : 'inactive'}" onclick="toggleUserInterest('${cause}')">
            ${cause} ${user.interests.includes(cause) ? '✓' : '+'}
          </span>
        `).join('')}
      </div>
      <div style="display:flex; justify-content:flex-end;">
        <button type="button" class="btn-primary" onclick="closeModal('generic-modal')">Save Interests</button>
      </div>
    </div>
  `;
  openModal('generic-modal');
}

function toggleUserInterest(cause) {
  const user = AppState.db.users.volunteer;
  if (user.interests.includes(cause)) {
    user.interests = user.interests.filter(c => c !== cause);
  } else {
    user.interests.push(cause);
  }
  DB.save(AppState.db);
  openEditInterestsModal();
  renderCurrentView();
}

// Edit Emergency Contact Modal
function openEditEmergencyModal() {
  const user = AppState.db.users.volunteer;
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Edit Emergency Contact";

  content.innerHTML = `
    <form onsubmit="handleSaveEmergencyContact(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Contact Name & Relationship</label>
        <input type="text" id="edit-emg-name" value="${user.emergencyContact.name}" required class="chat-text-input" />
      </div>
      <div class="form-group">
        <label class="form-label">Phone Number</label>
        <input type="text" id="edit-emg-phone" value="${user.emergencyContact.phone}" required class="chat-text-input" />
      </div>
      <div class="form-group">
        <label class="form-label">Relationship</label>
        <input type="text" id="edit-emg-rel" value="${user.emergencyContact.relation}" required class="chat-text-input" />
      </div>
      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Save Emergency Info</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleSaveEmergencyContact(e) {
  e.preventDefault();
  AppState.db.users.volunteer.emergencyContact = {
    name: document.getElementById('edit-emg-name').value,
    phone: document.getElementById('edit-emg-phone').value,
    relation: document.getElementById('edit-emg-rel').value
  };
  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast("Emergency contact updated!");
}

// Opportunity Details & Apply Modal
function openOpportunityDetailModal(oppId) {
  const opp = AppState.db.opportunities.find(o => o.id === oppId);
  if (!opp) return;

  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = opp.title;

  content.innerHTML = `
    <div>
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
        <span style="font-size:18px;">${opp.ngoIcon}</span>
        <strong style="color:#0f172a; font-size:15px;">${opp.ngo}</strong>
        <span class="opp-status-pill ${opp.status}" style="margin-left:auto;">${opp.status.toUpperCase()}</span>
      </div>

      <p style="font-size:14px; color:#475569; line-height:1.6; margin-bottom:18px;">${opp.description}</p>

      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:16px; display:grid; grid-template-columns:1fr 1fr; gap:12px; font-size:13px; margin-bottom:20px;">
        <div>📍 <strong>Location:</strong> ${opp.location}</div>
        <div>📅 <strong>Start Date:</strong> ${opp.startDate}</div>
        <div>⏱️ <strong>Commitment:</strong> ${opp.weeklyHours} hrs/week</div>
        <div>🗓️ <strong>Schedule:</strong> ${opp.schedule}</div>
        <div>👥 <strong>Slots Left:</strong> ${opp.slotsLeft} of ${opp.slotsTotal}</div>
        <div>👤 <strong>Coordinator:</strong> ${opp.coordinator}</div>
      </div>

      <div style="margin-bottom:18px;">
        <div style="font-size:12px; font-weight:700; color:#334155; margin-bottom:6px;">Required Skills:</div>
        <div class="tag-chips-wrap">
          ${opp.skillsRequired.map(s => `<span class="pill-chip blue">${s}</span>`).join('')}
        </div>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button class="btn-secondary" onclick="closeModal('generic-modal')">Close</button>
        <button class="btn-primary" onclick="closeModal('generic-modal'); openApplyModal('${opp.id}')">Apply Now &rarr;</button>
      </div>
    </div>
  `;
  openModal('generic-modal');
}

// Apply Now Modal
function openApplyModal(oppId) {
  const opp = AppState.db.opportunities.find(o => o.id === oppId);
  if (!opp) return;

  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = `Apply for ${opp.title}`;

  content.innerHTML = `
    <form onsubmit="handleApplySubmit(event, '${opp.id}')" style="display:flex; flex-direction:column; gap:16px;">
      <div style="background:#ecfdf5; border:1px solid #a7f3d0; border-radius:10px; padding:12px; font-size:13px; color:#065f46;">
        Applying to <strong>${opp.ngo}</strong> • ${opp.weeklyHours} hrs/week in ${opp.location}
      </div>

      <div class="form-group">
        <label class="form-label">Available Time Slot</label>
        <select id="apply-time-slot" class="sort-select" style="width:100%; height:42px;">
          <option>Morning Shift (8:00 AM - 12:00 PM)</option>
          <option>Evening Shift (4:00 PM - 8:00 PM)</option>
          <option>Flexible Weekend Availability</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Why are you interested in this activity? (Cover note)</label>
        <textarea id="apply-notes" rows="4" style="width:100%; border:1px solid #cbd5e1; border-radius:10px; padding:12px; font-size:13px; outline:none;" required placeholder="Briefly introduce your motivation, previous volunteering experience or relevant skills..."></textarea>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Submit Application &rarr;</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleApplySubmit(e, oppId) {
  e.preventDefault();
  const opp = AppState.db.opportunities.find(o => o.id === oppId);
  if (!opp) return;

  // Add new application to DB
  const newApp = {
    id: `app-${Date.now()}`,
    opportunityId: opp.id,
    title: opp.title,
    ngo: opp.ngo,
    status: 'under_review',
    appliedDate: 'Today',
    location: opp.location,
    hoursWeek: `${opp.weeklyHours} hrs/week`,
    duration: 'For 3 months',
    image: 'assets/images/hero_planting.jpg',
    progressStep: 2,
    statusText: 'Your application is under review. The NGO will update you soon.',
    timeline: [
      { title: 'Application Submitted', time: 'Today, Just now', done: true },
      { title: 'Review in Progress', time: 'In progress', done: true },
      { title: 'Final Decision', time: 'Pending', done: false }
    ]
  };

  AppState.db.applications.unshift(newApp);
  opp.slotsLeft = Math.max(0, opp.slotsLeft - 1);
  DB.save(AppState.db);

  closeModal('generic-modal');
  navigateTo('applications');
  showToast(`Application for "${opp.title}" submitted successfully! Track it under My Applications.`);
}

// Log Hours Modal (Participation Tracking)
function openLogHoursModal() {
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Log Volunteer Hours";

  content.innerHTML = `
    <form onsubmit="handleLogHoursSubmit(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Activity / Task</label>
        <input type="text" id="log-activity" placeholder="e.g. Relief Material Packaging & Sorting" required class="chat-text-input" />
      </div>

      <div class="form-group">
        <label class="form-label">NGO Organization</label>
        <select id="log-ngo" class="sort-select" style="width:100%; height:42px;">
          <option>DisasterReady India</option>
          <option>GreenRoots Foundation</option>
          <option>SevaSathi NGO</option>
          <option>SportForAll</option>
          <option>HealthCare For All</option>
        </select>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Date Worked</label>
          <input type="date" id="log-date" required class="chat-text-input" />
        </div>
        <div class="form-group">
          <label class="form-label">Number of Hours</label>
          <input type="number" id="log-hours" min="1" max="24" value="4" required class="chat-text-input" />
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Supervisor / Coordinator Name</label>
        <input type="text" id="log-supervisor" placeholder="e.g. Rajesh Shinde" required class="chat-text-input" />
      </div>

      <div class="form-group">
        <label class="form-label">Description of Tasks Completed</label>
        <textarea id="log-notes" rows="3" style="width:100%; border:1px solid #cbd5e1; border-radius:10px; padding:10px; font-size:13px; outline:none;" placeholder="Summary of duties performed..."></textarea>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Submit Hours for Verification</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleLogHoursSubmit(e) {
  e.preventDefault();
  const hrs = parseInt(document.getElementById('log-hours').value);
  const newLog = {
    id: `hr-${Date.now()}`,
    date: document.getElementById('log-date').value || 'Oct 15, 2026',
    activity: document.getElementById('log-activity').value,
    ngo: document.getElementById('log-ngo').value,
    hours: hrs,
    status: 'verified', // Auto-approved for realistic demo
    supervisor: document.getElementById('log-supervisor').value,
    notes: document.getElementById('log-notes').value
  };

  AppState.db.hoursLog.unshift(newLog);
  AppState.db.users.volunteer.stats.hoursVolunteered += hrs;
  AppState.db.users.volunteer.stats.completedActivities += 1;
  DB.save(AppState.db);

  closeModal('generic-modal');
  renderCurrentView();
  showToast(`Successfully logged ${hrs} hours! Total volunteered hours updated.`);
}

// View Certificate Modal (Printable)
function openCertificateModal(certId) {
  const cert = AppState.db.certificates.find(c => c.id === certId);
  if (!cert) return;

  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Certificate of Appreciation";

  content.innerHTML = `
    <div>
      <div class="printable-certificate" id="printable-certificate-area">
        <div style="font-size:36px; margin-bottom:8px;">🎖️</div>
        <h2 class="cert-print-title">Certificate of Appreciation</h2>
        <p class="cert-print-subtitle">PROUDLY PRESENTED FOR OUTSTANDING VOLUNTARY COMMUNITY SERVICE TO</p>

        <div class="cert-recipient-name">${cert.recipient}</div>

        <p style="font-size:14px; color:#374151; max-width:500px; margin:0 auto 24px auto; line-height:1.6;">
          For dedicating <strong>${cert.hours} hours</strong> of exemplary volunteer service in the <strong>${cert.title}</strong> initiative organized by <strong>${cert.ngo}</strong>.
        </p>

        <div style="display:flex; justify-content:space-between; align-items:flex-end; border-top:1px solid #cbd5e1; padding-top:18px; margin-top:24px; font-size:12px; color:#475569;">
          <div style="text-align:left;">
            <div><strong>Date of Issue:</strong> ${cert.issuedDate}</div>
            <div><strong>Certificate ID:</strong> ${cert.certNumber}</div>
          </div>
          <div style="text-align:right;">
            <div style="font-family:'Brush Script MT', cursive; font-size:22px; color:#065f46;">${cert.signatory.split(',')[0]}</div>
            <div><strong>${cert.signatory}</strong></div>
          </div>
        </div>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
        <button class="btn-secondary" onclick="closeModal('generic-modal')">Close</button>
        <button class="btn-primary" onclick="printCertificate()">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print Certificate
        </button>
      </div>
    </div>
  `;
  openModal('generic-modal');
}

function printCertificate() {
  window.print();
}

// Post Opportunity Modal (For NGO Admin)
function openPostOpportunityModal() {
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Post New Volunteer Opportunity";

  content.innerHTML = `
    <form onsubmit="handlePostOpportunitySubmit(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Opportunity Title</label>
        <input type="text" id="post-title" placeholder="e.g. Community Health Camp Assistant" required class="chat-text-input" />
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Location (City, District)</label>
          <input type="text" id="post-location" placeholder="e.g. Mumbai, Maharashtra" required class="chat-text-input" />
        </div>
        <div class="form-group">
          <label class="form-label">Cause Category</label>
          <select id="post-category" class="sort-select" style="width:100%; height:42px;">
            <option>Environment</option>
            <option>Education</option>
            <option>Healthcare</option>
            <option>Social Welfare</option>
            <option>Disaster Relief</option>
          </select>
        </div>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Weekly Hours</label>
          <input type="number" id="post-hours" min="1" max="40" value="4" required class="chat-text-input" />
        </div>
        <div class="form-group">
          <label class="form-label">Total Volunteer Slots</label>
          <input type="number" id="post-slots" min="1" max="100" value="15" required class="chat-text-input" />
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Description & Responsibilities</label>
        <textarea id="post-desc" rows="3" style="width:100%; border:1px solid #cbd5e1; border-radius:10px; padding:10px; font-size:13px; outline:none;" required placeholder="Details on what volunteers will do..."></textarea>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Publish Opportunity</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handlePostOpportunitySubmit(e) {
  e.preventDefault();
  const titleVal = document.getElementById('post-title').value;
  const locVal = document.getElementById('post-location').value;
  const catVal = document.getElementById('post-category').value;
  const hrsVal = parseInt(document.getElementById('post-hours').value);
  const slotsVal = parseInt(document.getElementById('post-slots').value);
  const descVal = document.getElementById('post-desc').value;

  const newOpp = {
    id: `opp-${Date.now()}`,
    title: titleVal,
    ngo: AppState.db.users.ngo_admin.organization,
    ngoIcon: "🌱",
    status: "open",
    location: locVal,
    startDate: "Nov 25, 2026",
    applyBy: "Nov 20, 2026",
    weeklyHours: hrsVal,
    slotsTotal: slotsVal,
    slotsLeft: slotsVal,
    filledPercent: 0,
    categories: [catVal, "Community Outreach"],
    skillsRequired: ["Communication", "Event Management"],
    description: descVal,
    schedule: "Weekends 9:00 AM - 1:00 PM",
    coordinator: `${AppState.db.users.ngo_admin.name} (${AppState.db.users.ngo_admin.organization})`,
    bookmarked: false
  };

  AppState.db.opportunities.unshift(newOpp);
  DB.save(AppState.db);

  closeModal('generic-modal');
  navigateTo('opportunities');
  showToast(`Published new opportunity: "${titleVal}"!`);
}

// 1. Assign Task to Volunteer Modal ("Admin Add Kar Sake")
function openAssignTaskModal(defaultVolId) {
  const volunteers = AppState.db.volunteersList || [];
  const ngos = AppState.db.ngosList || [];
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Assign Task to Volunteer";

  content.innerHTML = `
    <form onsubmit="handleAssignTaskSubmit(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Select Volunteer</label>
        <select id="assign-volunteer-id" class="sort-select" style="width:100%; height:42px;">
          ${volunteers.map(v => `
            <option value="${v.id}" ${defaultVolId === v.id ? 'selected' : ''}>
              ${v.name} (${v.skills.slice(0, 2).join(', ')}) • Available: ${v.availability}
            </option>
          `).join('')}
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Task / Responsibility Title</label>
        <input type="text" id="assign-task-title" placeholder="e.g. Relief Material Packaging & Sorting - Sector 3" required class="chat-text-input" />
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Organizing NGO</label>
          <select id="assign-ngo-name" class="sort-select" style="width:100%; height:42px;">
            ${ngos.map(n => `<option value="${n.name}">${n.name}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Priority Level</label>
          <select id="assign-priority" class="sort-select" style="width:100%; height:42px;">
            <option value="high">High Priority</option>
            <option value="medium" selected>Medium Priority</option>
            <option value="low">Low Priority</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Target Completion Date (Due Date)</label>
        <input type="date" id="assign-due-date" required class="chat-text-input" value="2026-11-15" />
      </div>

      <div class="form-group">
        <label class="form-label">Specific Guidelines & Instructions</label>
        <textarea id="assign-instructions" rows="3" style="width:100%; border:1px solid #cbd5e1; border-radius:10px; padding:10px; font-size:13px; outline:none;" required placeholder="Enter duties, venue, contact supervisor on ground..."></textarea>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Assign Task & Notify Volunteer &rarr;</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleAssignTaskSubmit(e) {
  e.preventDefault();
  const volId = document.getElementById('assign-volunteer-id').value;
  const volunteer = (AppState.db.volunteersList || []).find(v => v.id === volId) || { name: "Ravi Yadav" };
  const taskTitle = document.getElementById('assign-task-title').value;
  const ngoName = document.getElementById('assign-ngo-name').value;
  const priority = document.getElementById('assign-priority').value;
  const dueDate = document.getElementById('assign-due-date').value;
  const instructions = document.getElementById('assign-instructions').value;

  const newTask = {
    id: `task-${Date.now()}`,
    taskTitle: taskTitle,
    volunteerName: volunteer.name,
    volunteerId: volId,
    ngoName: ngoName,
    assignedBy: AppState.db.users.ngo_admin.name,
    assignedDate: "Today",
    dueDate: dueDate,
    priority: priority,
    status: "in_progress",
    completionPercent: 10,
    instructions: instructions
  };

  AppState.db.assignedTasks.unshift(newTask);

  // Add event to audit log
  AppState.db.workAuditLog.unshift({
    id: `log-${Date.now()}`,
    event: "Task Assigned",
    detail: `Admin assigned '${taskTitle}' to volunteer ${volunteer.name}.`,
    timestamp: "Just now",
    icon: "📌",
    badgeColor: "purple"
  });

  // Add system notification
  AppState.db.notifications.unshift({
    id: `nt-${Date.now()}`,
    title: "New Task Assigned!",
    desc: `You have been assigned: ${taskTitle} by ${ngoName}.`,
    time: "Just now",
    unread: true
  });

  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast(`Successfully assigned task to ${volunteer.name}!`);
}

// 2. Register New NGO Partner Modal ("Admin Add Kar Sake")
function openAddNewNgoModal() {
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Register New NGO Partner";

  content.innerHTML = `
    <form onsubmit="handleAddNewNgoSubmit(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">NGO Organization Name</label>
        <input type="text" id="new-ngo-name" placeholder="e.g. Hope Child Welfare Foundation" required class="chat-text-input" />
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Registration / License Number</label>
          <input type="text" id="new-ngo-reg" placeholder="e.g. NGO-MH-2026-9921" required class="chat-text-input" />
        </div>
        <div class="form-group">
          <label class="form-label">Focus Area / Cause</label>
          <select id="new-ngo-category" class="sort-select" style="width:100%; height:42px;">
            <option>Education & Child Care</option>
            <option>Environment & Sustainability</option>
            <option>Disaster & Emergency Relief</option>
            <option>Healthcare & Medical Aid</option>
            <option>Animal Welfare</option>
            <option>Women Empowerment</option>
          </select>
        </div>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Lead Coordinator Name</label>
          <input type="text" id="new-ngo-admin" placeholder="e.g. Dr. Ramesh Gupta" required class="chat-text-input" />
        </div>
        <div class="form-group">
          <label class="form-label">Contact Email</label>
          <input type="email" id="new-ngo-email" placeholder="contact@hopechild.org" required class="chat-text-input" />
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Operating Location (City, District)</label>
        <input type="text" id="new-ngo-location" placeholder="e.g. Navi Mumbai, Maharashtra" required class="chat-text-input" />
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Register & Verify NGO Partner &rarr;</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleAddNewNgoSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('new-ngo-name').value;
  const reg = document.getElementById('new-ngo-reg').value;
  const cat = document.getElementById('new-ngo-category').value;
  const adminName = document.getElementById('new-ngo-admin').value;
  const email = document.getElementById('new-ngo-email').value;
  const location = document.getElementById('new-ngo-location').value;

  const newNgo = {
    id: `ngo-${Date.now()}`,
    name: name,
    regNumber: reg,
    adminName: adminName,
    email: email,
    phone: "+91 98200 00000",
    category: cat,
    location: location,
    activeDrives: 0,
    volunteersCount: 0,
    status: "Verified & Active"
  };

  AppState.db.ngosList.unshift(newNgo);

  AppState.db.workAuditLog.unshift({
    id: `log-${Date.now()}`,
    event: "NGO Registered",
    detail: `New partner NGO '${name}' successfully onboarded and verified.`,
    timestamp: "Just now",
    icon: "🏢",
    badgeColor: "blue"
  });

  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast(`Registered new NGO partner: "${name}"!`);
}

// 3. Issue Official Certificate Modal ("Admin Add Kar Sake")
function openIssueCertificateModal() {
  const volunteers = AppState.db.volunteersList || [];
  const ngos = AppState.db.ngosList || [];
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Issue Official Certificate of Appreciation";

  content.innerHTML = `
    <form onsubmit="handleIssueCertificateSubmit(event)" style="display:flex; flex-direction:column; gap:16px;">
      <div class="form-group">
        <label class="form-label">Recipient Volunteer</label>
        <select id="cert-vol-name" class="sort-select" style="width:100%; height:42px;">
          ${volunteers.map(v => `<option value="${v.name}">${v.name} (${v.email})</option>`).join('')}
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Certificate Title / Honor</label>
        <input type="text" id="cert-title-input" placeholder="e.g. Outstanding Community Leadership Award" required class="chat-text-input" />
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Issuing NGO</label>
          <select id="cert-ngo-input" class="sort-select" style="width:100%; height:42px;">
            ${ngos.map(n => `<option value="${n.name}">${n.name}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Hours Recognized</label>
          <input type="number" id="cert-hours-input" value="15" min="1" max="500" required class="chat-text-input" />
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Signatory Authority (Name & Title)</label>
        <input type="text" id="cert-signatory-input" value="Priya Nair, Program Director" required class="chat-text-input" />
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary" style="background:#d97706;">Award & Issue Certificate &rarr;</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleIssueCertificateSubmit(e) {
  e.preventDefault();
  const recipient = document.getElementById('cert-vol-name').value;
  const certTitle = document.getElementById('cert-title-input').value;
  const ngo = document.getElementById('cert-ngo-input').value;
  const hours = parseInt(document.getElementById('cert-hours-input').value);
  const signatory = document.getElementById('cert-signatory-input').value;

  const newCert = {
    id: `cert-${Date.now()}`,
    title: certTitle,
    ngo: ngo,
    recipient: recipient,
    hours: hours,
    issuedDate: "October 16, 2026",
    certNumber: `VL-OFF-${Math.floor(1000 + Math.random() * 9000)}`,
    seal: `${ngo} Official Seal`,
    signatory: signatory
  };

  AppState.db.certificates.unshift(newCert);
  AppState.db.users.volunteer.stats.certificatesEarned += 1;

  AppState.db.workAuditLog.unshift({
    id: `log-${Date.now()}`,
    event: "Certificate Awarded",
    detail: `Official Certificate '${certTitle}' awarded to ${recipient} by ${ngo}.`,
    timestamp: "Just now",
    icon: "🎖️",
    badgeColor: "rose"
  });

  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast(`Awarded certificate "${certTitle}" to ${recipient}!`);
}

// 4. Update Task Progress Modal ("Dekh Sake Kaisa Work Ho Raha Hai")
function openUpdateTaskProgressModal(taskId) {
  const task = (AppState.db.assignedTasks || []).find(t => t.id === taskId);
  if (!task) return;

  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = `Update Progress: ${task.taskTitle}`;

  content.innerHTML = `
    <form onsubmit="handleUpdateTaskProgress(event, '${task.id}')" style="display:flex; flex-direction:column; gap:16px;">
      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px; font-size:13px;">
        Volunteer: <strong>${task.volunteerName}</strong> • NGO: <strong>${task.ngoName}</strong><br/>
        Due: <strong>${task.dueDate}</strong>
      </div>

      <div class="form-group">
        <label class="form-label">Completion Percentage: <span id="lbl-task-prog-val" style="color:var(--primary); font-weight:800;">${task.completionPercent}%</span></label>
        <input type="range" id="update-task-prog" min="0" max="100" value="${task.completionPercent}" oninput="document.getElementById('lbl-task-prog-val').textContent = this.value + '%'" style="accent-color:var(--primary);" />
      </div>

      <div class="form-group">
        <label class="form-label">Task Status</label>
        <select id="update-task-status" class="sort-select" style="width:100%; height:42px;">
          <option value="in_progress" ${task.status === 'in_progress' ? 'selected' : ''}>In Progress</option>
          <option value="completed" ${task.status === 'completed' ? 'selected' : ''}>Completed & Verified</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Progress Note</label>
        <input type="text" id="update-task-note" placeholder="e.g. Ground inspection completed, final tally pending..." class="chat-text-input" />
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn-secondary" onclick="closeModal('generic-modal')">Cancel</button>
        <button type="submit" class="btn-primary">Save Progress Update</button>
      </div>
    </form>
  `;
  openModal('generic-modal');
}

function handleUpdateTaskProgress(e, taskId) {
  e.preventDefault();
  const task = (AppState.db.assignedTasks || []).find(t => t.id === taskId);
  if (!task) return;

  const prog = parseInt(document.getElementById('update-task-prog').value);
  const status = document.getElementById('update-task-status').value;
  const note = document.getElementById('update-task-note').value;

  task.completionPercent = prog;
  task.status = prog === 100 ? 'completed' : status;

  AppState.db.workAuditLog.unshift({
    id: `log-${Date.now()}`,
    event: "Task Progress Updated",
    detail: `${task.volunteerName}'s task '${task.taskTitle}' updated to ${prog}% (${task.status}). ${note ? 'Note: ' + note : ''}`,
    timestamp: "Just now",
    icon: "⚡",
    badgeColor: "blue"
  });

  DB.save(AppState.db);
  closeModal('generic-modal');
  renderCurrentView();
  showToast(`Updated progress for "${task.taskTitle}" to ${prog}%!`);
}

// Notifications Drawer Modal
function toggleNotificationsModal() {
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "Notifications";

  content.innerHTML = `
    <div style="display:flex; flex-direction:column; gap:12px;">
      ${AppState.db.notifications.map(n => `
        <div style="display:flex; gap:12px; padding:12px; border-radius:10px; background:${n.unread ? '#f0fdf4' : '#ffffff'}; border:1px solid ${n.unread ? '#bbf7d0' : '#e2e8f0'};">
          <div style="font-size:20px;">🔔</div>
          <div style="flex:1;">
            <div style="font-weight:700; font-size:13.5px; color:#0f172a;">${n.title}</div>
            <div style="font-size:12.5px; color:#475569; margin:2px 0;">${n.desc}</div>
            <div style="font-size:11px; color:#94a3b8;">${n.time}</div>
          </div>
        </div>
      `).join('')}
      <button class="btn-secondary" style="margin-top:8px; justify-content:center;" onclick="markAllNotificationsRead()">
        Mark All as Read
      </button>
    </div>
  `;
  openModal('generic-modal');
}

function markAllNotificationsRead() {
  AppState.db.notifications.forEach(n => n.unread = false);
  DB.save(AppState.db);
  closeModal('generic-modal');
  const indicator = document.querySelector('.notification-indicator');
  if (indicator) indicator.style.display = 'none';
  showToast("All notifications marked as read.");
}

// Project Synopsis Modal
function openSynopsisModal() {
  const s = AppState.db.synopsis;
  const content = document.getElementById('generic-modal-content');
  const title = document.getElementById('generic-modal-title');
  title.textContent = "TY_B.Sc.CS Project Synopsis";

  content.innerHTML = `
    <div style="max-height:70vh; overflow-y:auto; padding-right:6px; font-size:13.5px; line-height:1.6; color:#334155;">
      <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:10px; padding:14px; margin-bottom:16px;">
        <h4 style="font-size:16px; font-weight:800; color:#065f46;">${s.projectTitle}</h4>
        <div><strong>Authors:</strong> ${s.authors.map(a => a.name).join(' & ')}</div>
        <div><strong>Class:</strong> ${s.class} | <strong>System:</strong> Full-Stack NGO Volunteer Coordination</div>
      </div>

      <h4 style="font-weight:700; color:#0f172a; margin-top:12px;">Problem Statement Addressed:</h4>
      <ul style="margin-left:20px; margin-bottom:12px;">
        ${s.problemStatement.map(p => `<li>${p}</li>`).join('')}
      </ul>

      <h4 style="font-weight:700; color:#0f172a; margin-top:12px;">Objectives Met in this Application:</h4>
      <ul style="margin-left:20px; margin-bottom:12px;">
        ${s.objectives.map(o => `<li>${o}</li>`).join('')}
      </ul>

      <h4 style="font-weight:700; color:#0f172a; margin-top:12px;">System Architecture & Tools:</h4>
      <p>Frontend: HTML5, Vanilla CSS3, ES6+ JavaScript<br/>Backend & DB: PHP REST API scripts & MySQL Schema in <code>backend_php/</code>.</p>
    </div>
    <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:16px;">
      <button class="btn-secondary" onclick="closeModal('generic-modal')">Close</button>
      <button class="btn-primary" onclick="closeModal('generic-modal'); navigateTo('synopsis');">View Full Page Spec &rarr;</button>
    </div>
  `;
  openModal('generic-modal');
}

function showAboutModal() {
  openSynopsisModal();
}

function showContactModal() {
  showToast("Support coordinators: Abhishek Chaubey & Kashish Sharad Durgoli (TY B.Sc.CS)");
}

// Toast notification display helper
function showToast(message) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
