# VolunteerLink — Volunteer Coordination System for NGOs
**TY B.Sc.CS Project**
- **Authors:** Kashish Sharad Durgoli & Abhishek Chaubey
- **Academic Year:** 2026 – 2027
- **Class:** TY_B.Sc.CS

---

## 🌟 Project Overview
VolunteerLink is a centralized, digital volunteer management and coordination platform designed for Non-Governmental Organizations (NGOs) and passionate community volunteers. It replaces outdated, error-prone manual spreadsheets and registers with a modern, responsive, data-driven web application.

### Key Objectives Achieved (from Project Synopsis):
1. **Centralized Volunteer Database:** Digital records of volunteer identities, contact information, emergency contacts, and profile completion metrics.
2. **Skills & Availability Tracking:** Interactive day-by-day availability schedules (Mon–Sun) and preferred time slots (Morning/Evening), coupled with multi-skill and cause interest matching.
3. **Activity & Task Management:** NGOs can publish community drives, set required volunteer quotas, define prerequisite skills, and manage deadlines.
4. **Volunteer Assignment & Application Pipeline:** 4-step progress stepper (*Applied &rarr; Shortlisted &rarr; Accepted &rarr; Completed*) with milestone audit timelines and instant status notifications.
5. **Attendance & Participation Tracking:** Dedicated hours logging system, supervisor verification workflows, and automated generation of official printable **Certificates of Appreciation**.
6. **Direct Communication System:** Built-in messaging between volunteers and NGO coordinators with quick suggestion chips, unread badges, and contact options.
7. **Comprehensive Reporting:** Exportable volunteer attendance logs (CSV), impact analytics counters, and printable activity summaries.

---

## 🚀 How to Run the Website

### Option 1: Direct Browser Launch (Zero-Setup)
Simply double-click [`index.html`](index.html) in your file explorer to open it in Google Chrome, Microsoft Edge, or any modern web browser. All application data is persistently saved in your browser's local database.

### Option 2: Local Python Server (Recommended for Live Demo)
Run the following command in PowerShell or Terminal inside this directory:
```powershell
python -m http.server 8000
```
Then visit:
```
http://localhost:8000
```

### Option 3: PHP & MySQL with XAMPP / WAMP (For College Submission & Viva)
1. Copy this folder into your `xampp/htdocs/volunteerlink/` directory.
2. Open **PhpMyAdmin** (`http://localhost/phpmyadmin`).
3. Create a new database named `volunteerlink_db`.
4. Import [`backend_php/database.sql`](backend_php/database.sql).
5. Access the application via `http://localhost/volunteerlink/`.

---

## 🔑 Demo Accounts (Click-to-Autofill)
- **Volunteer:** `raviyadav@gmail.com` / `Volunteer@2026`
- **NGO Admin (GreenRoots Foundation):** `priya.nair@greenroots.org` / `NGOAdmin@2026`
- **Super Admin:** `admin@volunteerlink.org` / `SuperAdmin@2026`

---

## 📁 Project Directory Structure
```
website/
├── index.html                   # Master single-page application container
├── css/
│   └── styles.css               # Design system & responsive styles
├── js/
│   ├── data.js                  # Initial database seeds & local persistence
│   └── app.js                   # Application controller, routing & modals
├── assets/
│   └── images/
│       ├── ravi_avatar.jpg      # Profile photo
│       ├── hero_planting.jpg   # Tree planting drive banner
│       ├── riya_director.jpg    # NGO Director portrait
│       ├── flood_relief.jpg     # Flood rescue operation
│       └── teaching_kids.jpg    # Outdoor community school
├── backend_php/
│   ├── database.sql             # Complete MySQL table schemas & sample data
│   ├── config.php               # PDO database configuration
│   └── api.php                  # REST API endpoints
└── README.md                    # Project documentation
```
