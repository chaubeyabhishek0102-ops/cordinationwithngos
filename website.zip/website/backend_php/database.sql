-- =============================================================================
-- VolunteerLink - Volunteer Coordination System for NGOs
-- Database Schema for MySQL / PhpMyAdmin
-- TY_B.Sc.CS Project by Kashish Sharad Durgoli & Abhishek Chaubey
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `volunteerlink_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `volunteerlink_db`;

-- 1. Users Table (Volunteer, NGO Admin, Super Admin)
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT AUTO-INCREMENT PRIMARY KEY,
  `role` ENUM('volunteer', 'ngo_admin', 'super_admin') NOT NULL DEFAULT 'volunteer',
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `location` VARCHAR(150) DEFAULT 'Mumbai, Maharashtra',
  `avatar_url` VARCHAR(255) DEFAULT 'assets/images/ravi_avatar.jpg',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Volunteer Profiles Table
CREATE TABLE IF NOT EXISTS `volunteer_profiles` (
  `profile_id` INT AUTO-INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `quote` VARCHAR(255) DEFAULT 'Passionate about contributing to society through volunteering.',
  `about_me` TEXT DEFAULT NULL,
  `skills` TEXT DEFAULT NULL COMMENT 'Comma separated list of skills',
  `interests` TEXT DEFAULT NULL COMMENT 'Comma separated list of cause categories',
  `available_days` VARCHAR(100) DEFAULT 'Mon,Wed,Fri,Sat',
  `preferred_time_slots` VARCHAR(150) DEFAULT 'Morning (8AM - 12PM), Evening (4PM - 8PM)',
  `emergency_contact_name` VARCHAR(100) DEFAULT 'Avdhesh Yadav (Father)',
  `emergency_contact_phone` VARCHAR(20) DEFAULT '+91 98765 12345',
  `emergency_contact_relation` VARCHAR(50) DEFAULT 'Father',
  `allow_ngo_view` TINYINT(1) DEFAULT 1,
  `show_hours_public` TINYINT(1) DEFAULT 1,
  `show_email_public` TINYINT(1) DEFAULT 0,
  `total_hours_volunteered` INT DEFAULT 48,
  `completed_activities` INT DEFAULT 6,
  `certificates_earned` INT DEFAULT 4,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. NGOs Table
CREATE TABLE IF NOT EXISTS `ngos` (
  `ngo_id` INT AUTO-INCREMENT PRIMARY KEY,
  `admin_user_id` INT NOT NULL,
  `ngo_name` VARCHAR(150) NOT NULL,
  `registration_number` VARCHAR(100) NOT NULL,
  `focus_areas` VARCHAR(255) NOT NULL,
  `website` VARCHAR(200) DEFAULT NULL,
  `verified` TINYINT(1) DEFAULT 1,
  FOREIGN KEY (`admin_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Volunteer Opportunities Table
CREATE TABLE IF NOT EXISTS `opportunities` (
  `opportunity_id` INT AUTO-INCREMENT PRIMARY KEY,
  `ngo_id` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` TEXT NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `start_date` DATE NOT NULL,
  `apply_by` DATE NOT NULL,
  `weekly_hours` INT NOT NULL DEFAULT 4,
  `slots_total` INT NOT NULL DEFAULT 20,
  `slots_available` INT NOT NULL DEFAULT 20,
  `required_skills` VARCHAR(255) DEFAULT 'Communication',
  `status` ENUM('open', 'urgent', 'closed') DEFAULT 'open',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`ngo_id`) REFERENCES `ngos`(`ngo_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Applications Table
CREATE TABLE IF NOT EXISTS `applications` (
  `application_id` INT AUTO-INCREMENT PRIMARY KEY,
  `opportunity_id` INT NOT NULL,
  `volunteer_user_id` INT NOT NULL,
  `applied_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('applied', 'under_review', 'shortlisted', 'accepted', 'rejected') DEFAULT 'under_review',
  `notes` TEXT DEFAULT NULL,
  `selected_time_slot` VARCHAR(100) DEFAULT NULL,
  FOREIGN KEY (`opportunity_id`) REFERENCES `opportunities`(`opportunity_id`) ON DELETE CASCADE,
  FOREIGN KEY (`volunteer_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Volunteer Hours & Attendance Table
CREATE TABLE IF NOT EXISTS `volunteer_hours` (
  `record_id` INT AUTO-INCREMENT PRIMARY KEY,
  `volunteer_user_id` INT NOT NULL,
  `opportunity_id` INT DEFAULT NULL,
  `ngo_name` VARCHAR(150) NOT NULL,
  `activity_name` VARCHAR(200) NOT NULL,
  `date_worked` DATE NOT NULL,
  `hours_logged` INT NOT NULL,
  `supervisor_name` VARCHAR(100) NOT NULL,
  `notes` TEXT DEFAULT NULL,
  `status` ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
  `verified_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`volunteer_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Certificates Table
CREATE TABLE IF NOT EXISTS `certificates` (
  `certificate_id` INT AUTO-INCREMENT PRIMARY KEY,
  `volunteer_user_id` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `issuing_ngo` VARCHAR(150) NOT NULL,
  `hours_contributed` INT NOT NULL,
  `issue_date` DATE NOT NULL,
  `certificate_number` VARCHAR(100) NOT NULL UNIQUE,
  `signatory_name` VARCHAR(150) NOT NULL,
  FOREIGN KEY (`volunteer_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Messages & Communication Table
CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` INT AUTO-INCREMENT PRIMARY KEY,
  `sender_user_id` INT NOT NULL,
  `recipient_user_id` INT NOT NULL,
  `message_text` TEXT NOT NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `is_read` TINYINT(1) DEFAULT 0,
  FOREIGN KEY (`sender_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`recipient_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================================
-- Sample Seed Data for TY B.Sc.CS Testing
-- =============================================================================

INSERT INTO `users` (`user_id`, `role`, `full_name`, `email`, `password_hash`, `phone`, `location`, `avatar_url`) VALUES
(1, 'volunteer', 'Ravi Yadav', 'raviyadav@gmail.com', 'Volunteer@2026', '+91 98765 43210', 'Mumbai, Maharashtra', 'assets/images/ravi_avatar.jpg'),
(2, 'ngo_admin', 'Priya Nair', 'priya.nair@greenroots.org', 'NGOAdmin@2026', '+91 98200 55432', 'Mumbai, Maharashtra', 'assets/images/riya_director.jpg'),
(3, 'super_admin', 'Abhishek Chaubey (Super Admin)', 'admin@volunteerlink.org', 'SuperAdmin@2026', '+91 99999 00000', 'Mumbai, Maharashtra', 'assets/images/riya_director.jpg');

INSERT INTO `volunteer_profiles` (`profile_id`, `user_id`, `quote`, `about_me`, `skills`, `interests`, `total_hours_volunteered`, `completed_activities`, `certificates_earned`) VALUES
(1, 1, 'Passionate about contributing to society and making a positive impact through volunteering.', 'I am a Computer Science student passionate about using my skills for social good. I enjoy participating in community activities, helping NGOs and contributing to education, environment and disaster relief initiatives.', 'Communication, Teaching, Event Management, Computer Skills, First Aid', 'Education, Environment, Community Outreach, Disaster Relief', 48, 6, 4);

INSERT INTO `ngos` (`ngo_id`, `admin_user_id`, `ngo_name`, `registration_number`, `focus_areas`) VALUES
(1, 2, 'GreenRoots Foundation', 'MH/2018/00918', 'Environment, Urban Forestry, Beach Conservation');

INSERT INTO `opportunities` (`opportunity_id`, `ngo_id`, `title`, `description`, `category`, `location`, `start_date`, `apply_by`, `weekly_hours`, `slots_total`, `slots_available`, `required_skills`, `status`) VALUES
(1, 1, 'Beach Cleanup Volunteer', 'Join our team to keep beaches clean and promote environmental awareness in the community.', 'Environment', 'Vasai, Maharashtra', '2026-11-02', '2026-10-25', 3, 50, 12, 'Communication, Event Management', 'open'),
(2, 1, 'Underprivileged Kids Teaching', 'Help teach basic English, Math and computer skills to underprivileged children.', 'Education', 'Nallasopara, Maharashtra', '2026-10-28', '2026-10-20', 4, 15, 8, 'Teaching, Communication', 'urgent');

INSERT INTO `certificates` (`certificate_id`, `volunteer_user_id`, `title`, `issuing_ngo`, `hours_contributed`, `issue_date`, `certificate_number`, `signatory_name`) VALUES
(1, 1, 'Disaster Relief Champion 2026', 'DisasterReady India', 16, '2026-10-05', 'VL-DRI-2026-8819', 'Rajesh Shinde, Operations Head'),
(2, 1, 'Eco-Warrior Beach Conservation', 'GreenRoots Foundation', 12, '2026-09-24', 'VL-GRF-2026-4402', 'Priya Nair, Program Director');
