<?php
/**
 * VolunteerLink - REST API Controller
 * TY_B.Sc.CS Project by Kashish Sharad Durgoli & Abhishek Chaubey
 */

require_once 'config.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. Check Database Health
if ($action === 'health') {
    if ($pdo) {
        sendJsonResponse('success', ['connected' => true, 'database' => DB_NAME], 'Database connected.');
    } else {
        sendJsonResponse('fallback', ['connected' => false], 'Operating in offline browser storage mode.');
    }
}

// 2. Authenticate User
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $email = $input['email'] ?? '';
    $pass = $input['password'] ?? '';

    if ($pdo) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && $user['password_hash'] === $pass) {
            sendJsonResponse('success', $user, 'Login successful.');
        } else {
            sendJsonResponse('error', null, 'Invalid credentials.');
        }
    } else {
        // Mock fallback response
        sendJsonResponse('success', ['email' => $email, 'role' => 'volunteer', 'name' => 'Ravi Yadav'], 'Offline login demo verified.');
    }
}

// 3. Get Opportunities
if ($action === 'get_opportunities') {
    if ($pdo) {
        $stmt = $pdo->query("SELECT o.*, n.ngo_name FROM opportunities o JOIN ngos n ON o.ngo_id = n.ngo_id ORDER BY o.opportunity_id DESC");
        $opps = $stmt->fetchAll();
        sendJsonResponse('success', $opps);
    } else {
        sendJsonResponse('fallback', null, 'Use client-side local database.');
    }
}

// 4. Log Volunteer Hours
if ($action === 'log_hours' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if ($pdo) {
        $stmt = $pdo->prepare("INSERT INTO volunteer_hours (volunteer_user_id, ngo_name, activity_name, date_worked, hours_logged, supervisor_name, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([
            $input['user_id'] ?? 1,
            $input['ngo'] ?? 'DisasterReady India',
            $input['activity'] ?? 'Community Relief',
            $input['date'] ?? date('Y-m-d'),
            $input['hours'] ?? 4,
            $input['supervisor'] ?? 'Supervisor',
            $input['notes'] ?? ''
        ]);
        sendJsonResponse('success', ['insert_id' => $pdo->lastInsertId()], 'Hours logged for supervisor review.');
    } else {
        sendJsonResponse('success', ['mock' => true], 'Hours saved locally.');
    }
}

sendJsonResponse('error', null, 'Invalid API endpoint.');
?>
